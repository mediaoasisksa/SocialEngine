<?php

class Sesbasic_Model_Like extends Core_Model_Item_Abstract {

  protected $_searchTriggers = false;

}
