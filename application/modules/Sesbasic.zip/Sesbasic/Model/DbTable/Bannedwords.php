<?php

class Sesbasic_Model_DbTable_Bannedwords extends Engine_Db_Table
{

}
