ALTER TABLE `engine4_sesbasic_locations` ADD `venue` VARCHAR(255) NULL;
ALTER TABLE `engine4_sesbasic_locations` ADD `address` TEXT NULL;
ALTER TABLE `engine4_sesbasic_locations` ADD `address2` TEXT NULL;
ALTER TABLE `engine4_sesbasic_locations` ADD `city` VARCHAR(255) NULL;
ALTER TABLE `engine4_sesbasic_locations` ADD `state` VARCHAR(255) NULL;
ALTER TABLE `engine4_sesbasic_locations` ADD `zip` VARCHAR(255) NULL;
ALTER TABLE `engine4_sesbasic_locations` ADD `country` VARCHAR(255) NULL;