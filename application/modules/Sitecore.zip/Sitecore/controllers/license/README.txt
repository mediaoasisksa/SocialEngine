// $Id: README.txt, 2010-11-26 9:40:21Z SocialApps.tech Exp $

*******************************************************************************
SocialApps.tech Core Plugin
  by SocialApps.tech - info (at) SocialApps.tech (dot) com
*******************************************************************************

DESCRIPTION:
This folder contains the license for this plugin.

WARNING:
No changes should be made to the files in this folder.