<?php

/**

*/
class Hpbblock_Widget_CategorySliderController extends Engine_Content_Widget_Abstract {
  public function indexAction() {
	
	}
}
