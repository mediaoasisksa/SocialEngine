<?php

class CustomTheme_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}