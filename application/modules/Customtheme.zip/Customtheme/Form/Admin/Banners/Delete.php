<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    Core
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Delete.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    Core
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class CustomTheme_Form_Admin_Banners_Delete extends Engine_Form
{
  public function init()
  {
    $this
      ->setTitle('Delete Banner')
      ->setDescription('Are you sure you want to delete this banner?');
    
    $id = new Zend_Form_Element_Hidden('id');
    $id->addValidator('Int');

    $this->addElements(array(
      $id
    ));
    // Buttons
    $this->addElement('Button', 'submit', array(
      'label' => 'Delete Banner',
      'type' => 'submit',
      'ignore' => true,
      'decorators' => array('ViewHelper')
    ));

    $this->addElement('Cancel', 'cancel', array(
      'label' => 'cancel',
      'link' => true,
      'prependText' => ' or ',
      'href' => '',
      'onclick' => 'parent.Smoothbox.close();',
      'decorators' => array(
        'ViewHelper'
      )
    ));
    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons');
    $this->getDisplayGroup('buttons');
  }
}
