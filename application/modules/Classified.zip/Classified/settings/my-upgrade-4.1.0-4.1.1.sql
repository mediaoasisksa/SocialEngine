
UPDATE `engine4_core_content`
  SET `name` = 'classified.list-recent-classifieds'
  WHERE `name` = 'classified.list-recent-classifiedss' ;
