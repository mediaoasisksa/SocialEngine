UPDATE `engine4_core_menuitems` SET `params`='{"route":"classified_general","icon":"fa fa-search"}' WHERE `name`='classified_main_browse';
UPDATE `engine4_core_menuitems` SET `params`='{"route":"classified_general","action":"manage","icon":"fa fa-user"}' WHERE `name`='classified_main_manage';
UPDATE `engine4_core_menuitems` SET `params`='{"route":"classified_general","action":"create","icon":"fa fa-plus"}' WHERE `name`='classified_main_create';
