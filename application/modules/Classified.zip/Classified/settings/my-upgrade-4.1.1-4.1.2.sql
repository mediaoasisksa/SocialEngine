
/* Fix some incorrect default collations */
ALTER TABLE `engine4_classified_fields_maps` DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;
ALTER TABLE `engine4_classified_fields_search` DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;
