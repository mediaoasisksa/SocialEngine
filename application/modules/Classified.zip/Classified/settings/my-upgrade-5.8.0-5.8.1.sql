ALTER TABLE `engine4_classified_fields_options` ADD `type` tinyint(1) NOT NULL DEFAULT '0';
