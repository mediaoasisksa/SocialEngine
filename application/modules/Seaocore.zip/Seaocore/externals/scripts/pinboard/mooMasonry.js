/*
---
description: Masonry layout engine (converted from jQuery Masonry)

license: mooMasonry is dual-licensed under GPL and MIT, just like jQuery Masonry itself. You can use it for both personal and commercial applications.

authors:
- David DeSandro
- Olivier Refalo

requires:
- core/1.3.0:'*'

provides: [Element.masonry]
*/

var pinBoardSeaoMasonryClass = function(){

  this.options = {
    singleMode : false,
    columnWidth : undefined,
    itemSelector : undefined,
    appendedContent : undefined,
    resizeable : true
  }
	
  this.element = undefined,
  this.colW = undefined,
  this.colCount = undefined,
  this.lastColCount = undefined,
  this.colY = undefined,
  this.lastColY= undefined,
  this.bound = undefined,
  this.masoned = undefined,
  this.bricks = undefined,
  this.posLeft = undefined,
  this.brickParent = undefined,

  Implements = Options,

  this.initialize = function(element, options) {
    this.element = document.id(element);
    this.go(options);
  },
	
  this.go = function(options) {
    this.setOptions(options);
		
    if (this.masoned && options.appendedContent != undefined) {
      this.brickParent = options.appendedContent;
    } else {
      this.brickParent = this.element;
    }
		
    if (this.brickParent.children().length > 0) {
      this.masonrySetup();
      this.masonryArrange();
		
      var resizeOn = this.options.resizeable;
      if (resizeOn) {
        if(this.bound == undefined) {
          this.bound = this.masonryResize.bind(this);
          this.attach();
        }
      }

      if (!resizeOn) {
        this.detach();
      }
    }
  },

  this.attach = function() {
    window.on('resize', this.bound);
    return this;
  },

  this.detach = function() {
    if(this.bound != undefined ) {
      window.off('resize', this.bound);
      this.bound = undefined;
    }
    return this;
  },

  this.placeBrick = function(brick, setCount, setY, setSpan) {
    var shortCol = 0;
		
    for (var i = 0; i < setCount; i++) {
      if (setY[i] < setY[shortCol]) {
        shortCol = i;
      }
    }
		
    if(document.html().get('dir')=='rtl'){
		  brick.css({
		  top : setY[shortCol],
		  right : this.colW * shortCol + this.posLeft
		});
    }else{
		 brick.css({
		  top : setY[shortCol],
		  left : this.colW * shortCol + this.posLeft
		}); 
    }
		
    var size=brick.offset().y+brick.css('margin-top').toInt()+brick.css('margin-bottom').toInt();

    for (var i = 0; i < setSpan; i++) {
      this.colY[shortCol + i] = setY[shortCol] + size;
    }
  },

  this.masonrySetup = function() {
    var s = this.options.itemSelector;
    this.bricks = s == undefined ? this.brickParent.getChildren() : this.brickParent.find(s);
		
    if (this.options.columnWidth == undefined) {
      var b = this.bricks[0];
      if (this.element.offset().x == b.offset().x) {
        this.colW = b.getChildren()[0].offset().x + b.css('margin-left').toInt() + b.css('margin-right').toInt();
      } else {
        this.colW = b.offset().x + b.css('margin-left').toInt() + b.css('margin-right').toInt();
      }
    } else {
      this.colW = this.options.columnWidth;
    }
		
    var size = this.element.offset().x+this.element.css('margin-left').toInt()+this.element.css('margin-right').toInt();
    this.colCount = Math.floor(size / this.colW);
    this.colCount = Math.max(this.colCount, 1);
		
    return this;
  },

  this.masonryResize = function() {
    this.brickParent = this.element;
    this.lastColY=this.colY;
    this.lastColCount = this.colCount;
		
    this.masonrySetup();
		
    if (this.colCount != this.lastColCount) {
      this.masonryArrange();
    }
    return this;
  },

  this.masonryArrange = function() {
    // if masonry hasn't been called before
    if (!this.masoned) {
      this.element.css('position', 'relative');
    }
		
    if (!this.masoned || this.options.appendedContent != undefined) {
      // just the new bricks
      this.bricks.css('position', 'absolute');
    }
		
    // get top left position of where the bricks should be
    var cursor = scriptJquery.crtEle('div').appendTo(this.element, 'top');
		
    var pos = cursor.getPosition();
    var epos = this.element.getPosition();
		
    var posTop = pos.y - epos.y;
    this.posLeft = pos.x - epos.x;
		
    cursor.dispose();
		
    // set up column Y array
    if (this.masoned && this.options.appendedContent != undefined) {
      // if appendedContent is set, use colY from last call
      if(this.lastColY != undefined) {
        this.colY=this.lastColY; 
      }
		
      /*
			* in the case that the wall is not resizeable, but the colCount has
			* changed from the previous time masonry has been called
			*/
      for (var i = this.lastColCount; i < this.colCount; i++) {
        this.colY[i] = posTop;
      }
		
    } else {
      this.colY = [];
      for (var i = 0; i < this.colCount; i++) {
        this.colY[i] = posTop;
      }
    }
		
    // layout logic
    if (this.options.singleMode) {
      if (this.colCount == 1) {
        this.bricks.css({
          'position': 'relative',
          'top': '',
          'left': '',
          'right': '',
          'float': 'none'
        });
      } else {
        this.bricks.css({
          'float': ''
        });
        for (var k = 0; k < this.bricks.length; k++) {
          var brick = this.bricks[k];
          this.placeBrick(brick, this.colCount, this.colY, 1);
        }
      }
    } else {
      for (var k = 0; k < this.bricks.length; k++) {
        var brick = this.bricks[k];
		
        // how many columns does this brick span
        var size=brick.offset().x+brick.css('margin-left').toInt()+brick.css('margin-right').toInt();
        var colSpan = Math.ceil(size / this.colW);
        colSpan = Math.min(colSpan, this.colCount);
		
        if (colSpan == 1) {
          // if brick spans only one column, just like singleMode
          this.placeBrick(brick, this.colCount, this.colY, 1);
        } else {
          // brick spans more than one column
          // how many different places could this brick fit horizontally
          var groupCount = this.colCount + 1 - colSpan;
          var groupY = [0];
          // for each group potential horizontal position
          for (var i = 0; i < groupCount; i++) {
            groupY[i] = 0;
            // for each column in that group
            for (var j = 0; j < colSpan; j++) {
              // get the maximum column height in that group
              groupY[i] = Math.max(groupY[i], this.colY[i + j]);
            }
          }        					
          this.placeBrick(brick, groupCount, groupY, colSpan);
        } // else
      }
    } // /layout logic
		
    // set the height of the wall to the tallest column
    var wallH = 0;
    for (var i = 0; i < this.colCount; i++) {
      wallH = Math.max(wallH, this.colY[i]);
    }
		
    this.element.css('height', wallH - posTop);
		if (this.options.singleMode && this.colCount == 1) {
      this.element.css('height', 'auto');
    }
    // let listeners know that we are done
    this.element.fireEvent('masoned', this.element);
    this.masoned = true;
    this.options.appendedContent = undefined;
		
    // set all data so we can retrieve it for appended appendedContent
    // or anyone else's crazy jquery fun
    // this.element.data('masonry', props );
    return this;
  }

};

Element.implement({
 
  pinBoardSeaoMasonry : function(options) {
    new pinBoardSeaoMasonryClass(this, options);
  }
});
