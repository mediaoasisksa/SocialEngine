/**
 * SEAOAutocompleter.Local
 *
 * http://digitarald.de/project/autocompleter/
 *
 * @version		1.1.2
 *
 * @license		MIT-style license
 * @author		Harald Kirschner <mail [at] digitarald.de>
 * @copyright	Author
 */

SEAOAutocompleter.Local = function(){

	Extends = SEAOAutocompleter,

	options = {
		minLength: 0,
		delay: 200
	},

	this.initialize = function(element, tokens, options) {
		this.parent(element, options);
		this.tokens = tokens;
	},

	this.query = function() {
		this.update(this.filter());
	}

};