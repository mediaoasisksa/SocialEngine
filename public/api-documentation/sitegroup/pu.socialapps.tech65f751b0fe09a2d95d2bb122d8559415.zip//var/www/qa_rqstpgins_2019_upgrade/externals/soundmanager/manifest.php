<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'soundmanager',
    'version' => '5.9.1',
    'revision' => '$Revision: 10111 $',
    'path' => 'externals/soundmanager',
    'repository' => 'socialengine.com',
    'title' => 'SoundManager',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/soundmanager',
    ),
  )
) ?>
