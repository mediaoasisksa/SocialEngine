<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'sitepagegeolocation',
    'version' => '5.4.1',
    'path' => 'application/modules/Sitepagegeolocation',
    'title' => 'Directory / Pages - Geo Location Extension',
    'description' => 'Directory / Pages - Geo Location Extension',
      'author' => '<a href="http://www.socialapps.tech" style="text-decoration:underline;" target="_blank">SocialApps.tech</a>',
    'callback' => 
    array (
      'path' => 'application/modules/Sitepagegeolocation/settings/install.php',
      'class' => 'Sitepagegeolocation_Installer',
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' => 
    array (
      0 => 'application/modules/Sitepagegeolocation',
    ),
    'files' => 
    array (
      0 => 'application/languages/en/sitepagegeolocation.csv',
    ),
  ),
); ?>