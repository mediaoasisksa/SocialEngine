<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'sitedeeplinking',
    'version' => '4.10.3p1',
    'path' => 'application/modules/Sitedeeplinking',
    'title' => 'SEAO - Deep Linking',
    'description' => 'SEAO - Deep Linking',
    'author' => 'socialEngineAddons',
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Module',
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' => 
    array (
      0 => 'application/modules/Sitedeeplinking',
    ),
    'files' => 
    array (
      0 => 'application/languages/en/sitedeeplinking.csv',
    ),
  ),
); ?>