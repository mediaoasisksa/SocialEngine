<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'sitemobileandroidapp',
    'version' => '5.4.1',
    'path' => 'application/modules/Sitemobileandroidapp',
    'title' => 'Android Mobile Application',
    'description' => 'Android Application',
    'author' => '<a href="http://www.socialapps.tech" style="text-decoration:underline;" target="_blank">SocialApps.tech</a>',
     'dependencies' => array(
            array(
                'type' => 'module',
                'name' => 'sitemobile',
                'minVersion' => '4.8.5',
            ),
        ),
      'callback' => 
    array (
       'path' => 'application/modules/Sitemobileandroidapp/settings/install.php',
            'class' => 'Sitemobileandroidapp_Installer',
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' => 
    array (
      'application/modules/Sitemobileandroidapp',
      'application/modules/Sitemobileapp',
    ),
    'files' => 
    array (
      'application/languages/en/sitemobileandroidapp.csv',
      'application/languages/en/sitemobileapp.csv',
    ),
  ),
    
    
); ?>