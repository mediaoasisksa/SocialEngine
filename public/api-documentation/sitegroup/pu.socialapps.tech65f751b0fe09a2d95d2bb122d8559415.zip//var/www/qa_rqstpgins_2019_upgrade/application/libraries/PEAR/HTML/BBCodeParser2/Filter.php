<?php
require_once 'HTML/BBCodeParser2.php';

/**
*   Dummy class that filters need to extend from.
*/
class HTML_BBCodeParser2_Filter extends HTML_BBCodeParser2
{
}
