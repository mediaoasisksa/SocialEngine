<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'seao-jquery',
    'version' => '4.10.3p1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/seao-jquery',
    'repository' => 'socialengine.com',
    'title' => 'Uploader',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/uploader',
    )
  )
) ?>
