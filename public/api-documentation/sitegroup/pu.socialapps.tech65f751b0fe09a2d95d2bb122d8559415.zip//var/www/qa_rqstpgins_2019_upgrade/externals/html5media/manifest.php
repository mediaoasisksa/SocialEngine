<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'html5media',
    'version' => '5.9.1',
    'revision' => '$Revision: 10270 $',
    'path' => 'externals/html5media',
    'repository' => 'socialengine.com',
    'title' => 'Html5 Media',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/html5media',
    )
  )
) ?>
