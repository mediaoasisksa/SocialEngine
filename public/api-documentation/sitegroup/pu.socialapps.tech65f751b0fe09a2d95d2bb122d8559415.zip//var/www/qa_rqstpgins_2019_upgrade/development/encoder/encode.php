<?php

foreach( scandir($rootPath) as $baseDir ) {
  if( !is_dir($rootPath . $baseDir) || in_array($baseDir, array('.', '..')) ) {
    continue;
  }
  foreach( $paths as $dirPath ) {
    $dirPath = $baseDir . $dirPath;
    $path = $rootPath . $dirPath . '/';
    if( !file_exists($path) ) {
      continue;
    }
    foreach( scandir($path) as $filename ) {
      if( strpos($filename, '.php') === false ) {
        continue;
      }
      $string = str_replace(array('<?php', '?>'), '', file_get_contents($path . $filename));

      $encodeString = str_rot13(base64_encode(gzdeflate(base64_encode($string), 9)));
      $string = "eval(base64_decode(gzinflate(base64_decode(str_rot13('" . $encodeString . "')))));";
      for( $i = 0; $i < rand(30, 35); $i++ ) {
        $encodeString = str_rot13(base64_encode(gzdeflate($string, 9)));
        $string = "eval(gzinflate(base64_decode(str_rot13('" . $encodeString . "'))));";
      }
      for( $i = 0; $i < rand(10, 15); $i++ ) {
        $encodeString = base64_encode(str_rot13(gzdeflate($string, 9)));
        $string = "eval(gzinflate(str_rot13(base64_decode('" . $encodeString . "'))));";
      }
      for( $i = 0; $i < rand(20, 25); $i++ ) {
        $encodeString = str_rot13(base64_encode(gzdeflate($string, 9)));
        $string = "eval(gzinflate(base64_decode(str_rot13('" . $encodeString . "'))));";
      }
      for( $i = 0; $i < rand(1, 5); $i++ ) {
        $encodeString = base64_encode(str_rot13(gzdeflate($string, 9)));
        $string = "eval(gzinflate(str_rot13(base64_decode('" . $encodeString . "'))));";
      }
      for( $i = 0; $i < rand(15, 20); $i++ ) {
        $encodeString = str_rot13(base64_encode(gzdeflate(str_rot13($string), 9)));
        $string = "eval(str_rot13(gzinflate(base64_decode(str_rot13('" . $encodeString . "')))));";
      }
      for( $i = 0; $i < rand(21, 24); $i++ ) {
        $encodeString = base64_encode(str_rot13(gzdeflate(str_rot13($string), 9)));
        $string = "eval(str_rot13(gzinflate(str_rot13(base64_decode('" . $encodeString . "')))));";
      }
      for( $i = 0; $i < rand(8, 12); $i++ ) {
        $encodeString = utf8_encode(str_rot13(base64_encode(gzdeflate(str_rot13($string), 9))));
        $string = "eval(str_rot13(gzinflate(base64_decode(str_rot13(utf8_decode('" . $encodeString . "'))))));";
      }
      for( $i = 0; $i < rand(3, 6); $i++ ) {
        $encodeString = str_rot13(base64_encode(gzdeflate(str_rot13($string), 9)));
        $string = "eval(str_rot13(gzinflate(base64_decode(str_rot13('" . $encodeString . "')))));";
      }
      $string = '<?php ' . $string . ' ?>';
      $explodeDir = explode('/', $dirPath);
      $dirMPath = '';
      foreach( $explodeDir as $dirName ) {
        if( !file_exists($savePath . $dirMPath . $dirName) ) {
          mkdir($savePath . $dirMPath . $dirName);
        }
        $dirMPath .= $dirName . '/';
      }

      file_put_contents($savePath . $dirPath . '/' . $filename, $string);
      $encodedFiles[] = $dirPath . '/' . $filename;
    }
  }
}
