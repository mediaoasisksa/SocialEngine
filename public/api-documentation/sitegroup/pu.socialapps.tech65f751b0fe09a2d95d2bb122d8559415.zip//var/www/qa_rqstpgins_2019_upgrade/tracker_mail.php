<?php
    define('_ENGINE', true);
	  $campaign_id =$_GET['id'];
    $log = $_GET['log'];
    $email = $_GET['email'];

    if ($campaign_id && $log && $email) {

      // Read database file
      $filename = realpath(dirname(__FILE__)).'/application/settings/database.php';
      // $buffer = array();
      if( file_exists($filename) ) {
        $dbinfo = include $filename;
      } else {
        $dbinfo = array();
      }
      $link = 0;
      if( !empty($dbinfo) ) {
        $dbname = $dbinfo['params']['dbname'];
        
        $host = $dbinfo['params']['host'];
        $username = $dbinfo['params']['username'];
        $password = $dbinfo['params']['password'];
        $link = @mysqli_connect($host, $username, $password, $dbname);

        // Check connection
        if($link === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
        }
        $history = "SELECT * FROM `engine4_sitenewsletter_statisticshistory` where `campaign_id` = $campaign_id and `email` = '$email'";

        if( $historyResult = mysqli_query($link, $history) ) {
          if(mysqli_num_rows($historyResult) == 0){
            $insert = "INSERT INTO `engine4_sitenewsletter_statisticshistory` (campaign_id, email, view) VALUES ($campaign_id, '$email', 1)";
            if(mysqli_query($link, $insert)){
              echo "Records were inserted successfully.";
            } else {
              echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }

            $date = date('Y-m-d');
            // Attempt select query execution
            $sql = "SELECT * FROM `engine4_sitenewsletter_statistics` where `campaign_id` = $campaign_id and `date` = '".$date."'";
            
            if( $result = mysqli_query($link, $sql) ) {
              if(mysqli_num_rows($result) > 0){
                $row = mysqli_fetch_array($result);
                $viewed = ++$row['viewed'];
                $id = $row['statistics_id'];
                $update =  "UPDATE `engine4_sitenewsletter_statistics` SET `viewed`=  $viewed WHERE `statistics_id` = $id";
                if(mysqli_query($link, $update)){
                    echo "Records were updated successfully.";
                } else {
                    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }

              } else {
                $campaign = "SELECT `email_count` FROM `engine4_sitenewsletter_campaigns` where `campaign_id` = $campaign_id";
                if( $data = mysqli_query($link, $campaign) ) {
                  if(mysqli_num_rows($data) > 0){
                    $campaignData = mysqli_fetch_array($data);
                    $email_count = $campaignData['email_count'];
                  }
                }
                $insert =  "INSERT INTO `engine4_sitenewsletter_statistics` (`campaign_id`, `sent`, `viewed`, `date`) VALUES ($campaign_id, $email_count, 1, '".date('Y-m-d')."')";
                if(mysqli_query($link, $insert)){
                    echo "Records inserted successfully.";
                } else {
                    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }

              }
            }
          }
        }
      }
    }
    $file = realpath(dirname(__FILE__)).'/application/modules/Sitenewsletter/externals/images/Transparent.gif';

    //Get the filesize of the image for headers
    $filesize = filesize($file);
    //Now actually output the image requested, while disregarding if the database was affected
    header('Content-Type: ' . 'image/gif');
    header('Content-Disposition: inline; filename="blank.gif"');
    header('Pragma: public');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Cache-Control: private', false);
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . $filesize);
    readfile($file);
?>