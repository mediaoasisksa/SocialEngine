<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'scrollbars',
    'version' => '5.9.1',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/scrollbars',
    'repository' => 'socialengine.com',
    'title' => 'Scrollbars',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/scrollbars',
    )
  )
) ?>
