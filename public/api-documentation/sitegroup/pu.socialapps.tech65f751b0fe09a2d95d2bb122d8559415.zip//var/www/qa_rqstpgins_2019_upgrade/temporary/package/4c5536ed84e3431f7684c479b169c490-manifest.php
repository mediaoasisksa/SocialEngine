<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Sitevod
 * @copyright  Copyright 2018-2019 BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    $Id: 4.10.3 2018-09-08 00:00:00Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */
return array(
  'package' =>
  array(
    'type' => 'module',
    'name' => 'sitevod',
    'version' => '5.4.1',
    'path' => 'application/modules/Sitevod',
    'title' => 'AWS Video on Demand Plugin',
    'description' => 'AWS Video on Demand Plugin',
    'author' => '<a href="http://www.socialapps.tech" style="text-decoration:underline;" target="_blank">SocialApps.tech</a>',
    'callback' =>
    array(
      'class' => 'Engine_Package_Installer_Module',
    ),
    'actions' =>
    array(
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' =>
    array(
      0 => 'application/modules/Sitevod',
    ),
    'files' =>
    array(
      0 => 'application/languages/en/sitevod.csv',
    ),
  ),
  // Items ---------------------------------------------------------------------
  'items' => array(
    'sitevod_stream',
  ),
  // Hooks ---------------------------------------------------------------------
  'hooks' => array(
    array(
      'event' => 'onStorageFileCreateAfter',
      'resource' => 'Sitevod_Plugin_Core',
    ),
    array(
      'event' => 'onStorageFileUpdateAfter',
      'resource' => 'Sitevod_Plugin_Core',
    ),
  ),
);
?>