<?php return array (
  'package' =>
  array (
    'type' => 'external',
    'name' => 'fancymenu',
    'version' => '4.9.4p4',
    'path' => 'externals/fancymenu',
    'title' => 'Fancy Menu',
    'description' => 'External assets for Fancy Menu Widget',
    'author' => 'Webligo Developments',
    'actions' =>
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
    ),
    'directories' =>
    array (
      0 => 'externals/fancymenu',
    ),
  ),
); ?>
