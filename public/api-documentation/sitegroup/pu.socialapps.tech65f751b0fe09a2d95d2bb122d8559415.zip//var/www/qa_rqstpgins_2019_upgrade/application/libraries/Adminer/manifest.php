<?php
/**
 * SocialEngine
 *
 * @category   Engine
 * @package    Engine
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.net/license/
 * @version    $Id: manifest.php 7305 2010-09-07 06:49:55Z john $
 * @author     John Boehr <j@webligo.com>
 */
return array(
  'package' => array(
    'type' => 'library',
    'name' => 'adminer',
    'version' => '4.0.0',
    'revision' => '$Revision: 7305 $',
    'path' => 'application/libraries/Adminer',
    'repository' => 'socialengine.net',
    'title' => 'Adminer',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.net/license/',
    'actions' => array(
      'install',
      'upgrade',
      'refresh',
      'remove',
    ),
    'directories' => array(
      'application/libraries/Adminer',
    ),
  )
) ?>