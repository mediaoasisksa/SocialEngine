<?php

class Engine_Boot_Advancedpagecache extends Engine_Boot_Abstract
{

  public function beforeBoot()
  {
    if( empty($_SERVER['REQUEST_URI']) ) {
      return;
    }

    $getRequestUri = trim(htmlspecialchars($_SERVER['REQUEST_URI']), '/');
    if( strstr($getRequestUri, "api/rest") ) {
      return;
    }

    $rootPath = realpath(dirname(dirname(__FILE__)));
    $ds = DIRECTORY_SEPARATOR;
    if( !file_exists($rootPath . $ds . 'application' . $ds . 'advancedpagecache.php') ) {
      return;
    }
    $applicationPathSettings = $rootPath . $ds . 'application' . $ds . 'settings';
    if( !file_exists($applicationPathSettings . $ds . 'general.php') ) {
      return;
    }
    defined('_ENGINE') || define('_ENGINE', true);
    $generalConfig = include $applicationPathSettings . $ds . 'general.php';
    $enabled_modules_file = $applicationPathSettings . $ds . 'enabled_module_directories.php';
    $enabled_modules = array();
    if( file_exists($enabled_modules_file) ) {
      $enabled_modules = include $enabled_modules_file;
    }
    if( !in_array('Advancedpagecache', $enabled_modules) ) {
      return;
    }
    $cacheConfig = array();
    $advancedpageCacheConfigFile = $applicationPathSettings . $ds . 'advancedpagecache.php';
    if( file_exists($advancedpageCacheConfigFile) ) {
      $cacheConfig = include $advancedpageCacheConfigFile;
    }
    if( $cacheConfig && empty($cacheConfig['disable_browse']) ) {
      return;
    }
    $this->_boot->setRootBootFileName('advancedpagecache.php');
    $this->_boot->setRootBootDir('application');
  }

}