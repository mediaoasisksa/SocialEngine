<?php

class Engine_Boot_Siteerror extends Engine_Boot_Abstract
{

  public function beforeBoot()
  {
    $rootPath = realpath(dirname(dirname(__FILE__)));
    $ds = DIRECTORY_SEPARATOR;
    $applicationPathSettings = $rootPath . $ds . 'application' . $ds . 'settings';
    if( !file_exists($applicationPathSettings . $ds . 'general.php') ) {
      return;
    }
    defined('_ENGINE') || define('_ENGINE', true);
    $generalConfig = include $applicationPathSettings . $ds . 'general.php';
    $enabled_modules_file = $applicationPathSettings . $ds . 'enabled_module_directories.php';
    $enabled_modules = array();
    if( file_exists($enabled_modules_file) ) {
      $enabled_modules = include $enabled_modules_file;
    }
    if( !in_array('Siteerror', $enabled_modules) ) {
      return;
    }
    if( !empty($generalConfig['maintenance']['enabled']) && !empty($generalConfig['maintenance']['code']) ) {
      $code = $generalConfig['maintenance']['code'];
      if( @$_REQUEST['en4_maint_code'] == $code || @$_COOKIE['en4_maint_code'] == $code ) {
        if( @$_COOKIE['en4_maint_code'] !== $code ) {
          setcookie('en4_maint_code', $code, time() + (86400 * 7), '/');
        }
      } else {
        header('HTTP/1.1 503 Service Temporarily Unavailable');
        header('Status: 503 Service Temporarily Unavailable');
        header('Retry-After: 300'); //300 seconds
        $filePath = $rootPath . str_replace('/', $ds, '/public/siteerror-maintenance.html');
        if( file_exists($filePath) ) {
          echo file_get_contents($filePath);
        } else {
          echo file_get_contents($rootPath . $ds . 'application' . $ds . 'maintenance.html');
        }
        exit();
      }
    }
  }

}