<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Classrooms.php 10049 2013-06-06 22:24:49Z shaun $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Model_DbTable_Attendee extends Core_Model_Item_DbTable_Abstract
{
    protected $_rowClass = 'Classroom_Model_Attendee';


    public function getAttendee($class_id)
    {
        if(!Engine_Api::_()->user()->getViewer()->getIdentity()) {
            return false;
        }
        
       $select = $this->select()
        ->where('user_id = ?', Engine_Api::_()->user()->getViewer()->getIdentity())
        ->where('class_id = ?', $class_id)
        ->limit(1);
    
         $results = $this->fetchRow($select);
         $info= array();
        if($results) {
            $info = $results->toArray();
        }
       
       return $info;
    }
}
