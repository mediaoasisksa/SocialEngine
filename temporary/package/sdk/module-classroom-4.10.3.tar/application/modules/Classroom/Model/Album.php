<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Album.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Model_Album extends Core_Model_Item_Collection
{
  protected $_parent_type = 'classroom';

  protected $_owner_type = 'classroom';

  protected $_children_types = array('classroom_photo');

  protected $_collectible_type = 'classroom_photo';

  public function getHref($params = array())
  {
    $params = array_merge(array(
      'route' => 'classroom_profile',
      'reset' => true,
      'id' => $this->getClassroom()->getIdentity(),
      //'album_id' => $this->getIdentity(),
    ), $params);
    $route = $params['route'];
    $reset = $params['reset'];
    unset($params['route']);
    unset($params['reset']);
    return Zend_Controller_Front::getInstance()->getRouter()
      ->assemble($params, $route, $reset);
  }

  public function getClassroom()
  {
    return $this->getOwner();
    //return Engine_Api::_()->getItem('classroom', $this->classroom_id);
  }

  public function getAuthorizationItem()
  {
    return $this->getParent('classroom');
  }

  protected function _delete()
  {
    // Delete all child posts
    $photoTable = Engine_Api::_()->getItemTable('classroom_photo');
    $photoSelect = $photoTable->select()->where('album_id = ?', $this->getIdentity());
    foreach( $photoTable->fetchAll($photoSelect) as $classroomPhoto ) {
      $classroomPhoto->delete();
    }

    parent::_delete();
  }
}