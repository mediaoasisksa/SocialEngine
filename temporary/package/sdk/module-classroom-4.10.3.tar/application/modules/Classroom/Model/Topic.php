<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Model_Topic extends Core_Model_Item_Abstract
{
  protected $_parent_type = 'classroom';

  protected $_owner_type = 'user';

  protected $_children_types = array('classroom_post');
  
  public function isSearchable()
  {
    $classroom = $this->getParentClassroom();
    if( !($classroom instanceof Core_Model_Item_Abstract) ) {
      return false;
    }
    return $classroom->isSearchable();
  }

  public function getHref($params = array())
  {
    $params = array_merge(array(
      'route' => 'classroom_topic',
      'controller' => 'topic',
      'action' => 'view',
      'classroom_id' => $this->classroom_id,
      'topic_id' => $this->getIdentity(),
      'slug' => $this->getSlug(),
    ), $params);
    $route = @$params['route'];
    unset($params['route']);
    return Zend_Controller_Front::getInstance()->getRouter()->assemble($params, $route, true);
  }

  public function getDescription()
  {
    $firstPost = $this->getFirstPost();
    $content = '';
    if (null !== $firstPost) {        
        $content = $firstPost->body;
        // strip HTML and BBcode
        $content = strip_tags($content);
        $content = preg_replace('|[[\/\!]*?[^\[\]]*?]|si', '', $content);
        $content = ( Engine_String::strlen($content) > 255 ? Engine_String::substr($content, 0, 255) . '...' : $content );
    }
    return $content;
  }
  
  public function getParentClassroom()
  {
    return Engine_Api::_()->getItem('classroom', $this->classroom_id);
  }

  public function getFirstPost()
  {
    $table = Engine_Api::_()->getDbtable('posts', 'classroom');
    $select = $table->select()
      ->where('topic_id = ?', $this->getIdentity())
      ->order('post_id ASC')
      ->limit(1);

    return $table->fetchRow($select);
  }

  public function getLastPost()
  {
    $table = Engine_Api::_()->getItemTable('classroom_post');
    $select = $table->select()
      ->where('topic_id = ?', $this->getIdentity())
      ->order('post_id DESC')
      ->limit(1);

    return $table->fetchRow($select);
  }

  public function getLastPoster()
  {
    return Engine_Api::_()->getItem('user', $this->lastposter_id);
  }

  public function getAuthorizationItem()
  {
    return $this->getParent('classroom');
  }



  // Internal hooks

  protected function _insert()
  {
    if( $this->_disableHooks ) return;
    
    if( !$this->classroom_id )
    {
      throw new Exception('Cannot create topic without classroom_id');
    }

    /*
    $this->getParentClassroom()->setFromArray(array(

    ))->save();
    */

    parent::_insert();
  }

  protected function _delete()
  {
    if( $this->_disableHooks ) return;
    
    // Delete all child posts
    $postTable = Engine_Api::_()->getItemTable('classroom_post');
    $postSelect = $postTable->select()->where('topic_id = ?', $this->getIdentity());
    foreach( $postTable->fetchAll($postSelect) as $classroomPost ) {
      $classroomPost->disableHooks()->delete();
    }
    
    // delete classroom_topic_creat and classroom_topic_reply
    
    parent::_delete();
  }

  public function canEdit($user)
  {
    return $this->getParent()->authorization()->isAllowed($user, 'edit') || $this->getParent()->authorization()->isAllowed($user, 'topic.edit') || $this->isOwner($user);
  }
}