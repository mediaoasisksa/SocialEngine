<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Topics.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Model_DbTable_Topics extends Engine_Db_Table
{
  protected $_rowClass = 'Classroom_Model_Topic';
  
  public function getChildrenSelectOfClassroom($classroom, $params)
  {
    $select = $this->select()->where('classroom_id = ?', $classroom->classroom_id);
    return $select;
  }
}