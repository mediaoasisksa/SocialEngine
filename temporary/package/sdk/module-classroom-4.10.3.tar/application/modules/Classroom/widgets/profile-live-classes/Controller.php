<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Controller.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
require_once("application/modules/Classroom/controllers/GetClassDetails.php"); 
 
class Classroom_Widget_ProfileLiveClassesController extends Engine_Content_Widget_Abstract
{
 
  protected $_childCount;
  
  public function indexAction()
  {
    // Don't render this if not authorized
    $viewer = Engine_Api::_()->user()->getViewer();
    if( !Engine_Api::_()->core()->hasSubject() ) {
      return $this->setNoRender();
    }

    // Get subject and check auth
    $this->view->classroom = $subject = Engine_Api::_()->core()->getSubject();
    if( !$subject->authorization()->isAllowed($viewer, 'view') ) {
      return $this->setNoRender();
    }
        $this->view->canAdd = $canAdd = $subject->authorization()->isAllowed(null,  'event') && Engine_Api::_()->authorization()->isAllowed('event', null, 'create');

    // Get paginator
    $this->view->paginator = $paginator = Engine_Api::_()->getItemTable('classroom')->getClassroomPaginator(array(
      'parent_type' => 'classroom',
      'class_id' => true,
      'parent_id' => $subject->getIdentity()
    ));

    // Set item count per page and current page number
    $paginator->setItemCountPerPage($this->_getParam('itemCountPerPage', 5));
    $paginator->setCurrentPageNumber($this->_getParam('page', 1));

    // Add count to title if configured
    if( $this->_getParam('titleCount', false) && $paginator->getTotalItemCount() > 0 ) {
      $this->_childCount = $paginator->getTotalItemCount();
    }

  }

  public function getChildCount()
  {
    return $this->_childCount;
  }


}