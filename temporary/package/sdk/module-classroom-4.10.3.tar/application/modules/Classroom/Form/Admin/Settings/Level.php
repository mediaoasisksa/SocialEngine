
<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Level.php 9802 2012-10-20 16:56:13Z pamela $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Form_Admin_Settings_Level extends Authorization_Form_Admin_Level_Abstract
{
  public function init()
  {
    parent::init();

    // My stuff
    $this
      ->setTitle('Member Level Settings')
      ->setDescription('CLASSROOM_FORM_ADMIN_LEVEL_DESCRIPTION');

    // Element: view
    $this->addElement('Radio', 'view', array(
      'label' => 'Allow Viewing of Classrooms?',
      'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_VIEW_DESCRIPTION',
      'multiOptions' => array(
        2 => 'Yes, allow members to view all classrooms, even private ones.',
        1 => 'Yes, allow viewing and subscription of classrooms.',
        0 => 'No, do not allow classrooms to be viewed.',
      ),
      'value' => ( $this->isModerator() ? 2 : 1 ),
    ));
    if( !$this->isModerator() ) {
      unset($this->view->options[2]);
    }

    if( !$this->isPublic() ) {

      // Element: create
      $this->addElement('Radio', 'create', array(
        'label' => 'Allow Creation of Classrooms?',
        'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_CREATE_DESCRIPTION',
        'multiOptions' => array(
          1 => 'Yes, allow creation of classrooms.',
          0 => 'No, do not allow classrooms to be created.',
        ),
        'value' => 1,
      ));

      // Element: edit
      $this->addElement('Radio', 'edit', array(
        'label' => 'Allow Editing of Classrooms?',
        'description' => 'Do you want to let users edit and delete classrooms?',
        'multiOptions' => array(
          2 => 'Yes, allow members to edit everyone\'s classrooms.',
          1 => 'Yes, allow  members to edit their own classrooms.',
          0 => 'No, do not allow classrooms to be edited.',
        ),
        'value' => ( $this->isModerator() ? 2 : 1 ),
      ));
      if( !$this->isModerator() ) {
        unset($this->edit->options[2]);
      }

      // Element: delete
      $this->addElement('Radio', 'delete', array(
        'label' => 'Allow Deletion of Classrooms?',
        'description' => 'Do you want to let members delete classrooms? If set to no, some other settings on this page may not apply.',
        'multiOptions' => array(
          2 => 'Yes, allow members to delete all classrooms.',
          1 => 'Yes, allow members to delete their own classrooms.',
          0 => 'No, do not allow members to delete their classrooms.',
        ),
        'value' => ( $this->isModerator() ? 2 : 1 ),
      ));
      if( !$this->isModerator() ) {
        unset($this->delete->options[2]);
      }

      // Element: comment
      $this->addElement('Radio', 'comment', array(
        'label' => 'Allow Commenting on Classrooms?',
        'description' => 'Do you want to let members of this level comment on classrooms?',
        'multiOptions' => array(
          2 => 'Yes, allow members to comment on all classrooms, including private ones.',
          1 => 'Yes, allow members to comment on classrooms.',
          0 => 'No, do not allow members to comment on classrooms.',
        ),
        'value' => ( $this->isModerator() ? 2 : 1 ),
      ));
      if( !$this->isModerator() ) {
        unset($this->comment->options[2]);
      }

      // Element: auth_view
      $this->addElement('MultiCheckbox', 'auth_view', array(
        'label' => 'Classroom Privacy',
        'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_AUTHVIEW_DESCRIPTION',
        'multiOptions' => array(
          'everyone' => 'Everyone',
          'registered' => 'Registered Members',
          'member' => 'Members Only',
          //'officer' => 'Officers and Owner Only',
          //'owner' => 'Owner Only'
        )
      ));

      // Element: auth_comment
      $this->addElement('MultiCheckbox', 'auth_comment', array(
        'label' => 'Classroom Posting Options',
        'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_AUTHCOMMENT_DESCRIPTION',
        'multiOptions' => array(
          'registered' => 'Registered Members',
          'member' => 'All Members',
          'officer' => 'Officers and Owner Only',
          //'owner' => 'Owner Only',
        )
      ));

      // Element: auth_photo
      $this->addElement('MultiCheckbox', 'auth_photo', array(
        'label' => 'Photo Upload Options',
        'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_AUTHPHOTO_DESCRIPTION',
        'multiOptions' => array(
          'registered' => 'Registered Members',
          'member' => 'All Members',
          'officer' => 'Officers and Owner Only',
          //'owner' => 'Owner Only',
        )
      ));

      // Element: auth_event
      $this->addElement('MultiCheckbox', 'auth_event', array(
        'label' => 'Event Creation Options',
        'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_AUTHEVENT_DESCRIPTION',
        'multiOptions' => array(
          'registered' => 'Registered Members',
          'member' => 'All Members',
          'officer' => 'Officers and Owner Only',
          //'owner' => 'Owner Only',
        )
      ));

      // Element: style
      $this->addElement('Radio', 'style', array(
        'label' => 'Allow Classroom Style',
        'required' => true,
        'multiOptions' => array(
          1 => 'Yes, allow custom classroom styles.',
          0 => 'No, do not allow custom classroom styles.'
        ),
        'value' => 1,
      ));

      // Element: create
      $this->addElement('Radio', 'coverphotoupload', [
        'label' => 'Allow to Upload Cover Photos?',
        'description' => 'Do you want to let members upload Cover Photos for their classrooms?',
        'multiOptions' => array(
          1 => 'Yes, allow user to upload cover photos',
          0 => 'No, do not allow users to upload cover photos.'
        ),
        'value' => 1,
      ]);

      $this->addElement('dummy', 'coverphoto_dummy', [
        'label' => 'Default Classroom Cover Photo',
      ]);

      $this->coverphoto_dummy->addDecorator('Description', [
        'placement' => 'PREPEND',
        'class' => 'description',
        'escape' => false,
        'order' => 998
      ]);
    
    // Element: commentHtml
    $this->addElement('Text', 'commentHtml', array(
      'label' => 'Allow HTML in posts?',
      'description' => 'CLASSROOM_FORM_ADMIN_LEVEL_CONTENTHTML_DESCRIPTION',
      'order' => 999
    ));
    
    
    $this->addElement('Text', 'max', array(
        'label' => 'Maximum Allowed Classrooms Entries?',
        'description' => 'Enter the maximum number of allowed classroom entries. The field must contain an integer between 1 and 999, or 0 for unlimited.',
        'validators' => array(
          array('Int', true),
          new Engine_Validate_AtLeast(0),
        ),
      ));
      }
  }
}