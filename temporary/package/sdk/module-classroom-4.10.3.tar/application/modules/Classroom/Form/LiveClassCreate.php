<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Create.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Form_LiveClassCreate extends Engine_Form
{
  public function init()
  {
    $user = Engine_Api::_()->user()->getViewer();
$settings = Engine_Api::_()->getApi('settings', 'core');
    $this
      ->setTitle('Schedule a Meeting')->setAttrib('id', 'event_create_form');

    $this->addElement('Text', 'title', array(
      'label' => 'Meeting Title',
      'allowEmpty' => false,
      'required' => true,
      'validators' => array(
        array('NotEmpty', true),
        array('StringLength', false, array(1, 64)),
      ),
      'filters' => array(
        'StripTags',
        new Engine_Filter_Censor(),
      ),
    ));

        // Start time
    $start = new Engine_Form_Element_CalendarDateTime('starttime');
    $start->setLabel("Start Time");
    $start->setAllowEmpty(false);
    $start->setRequired(true);  
    $this->addElement($start);
    
    
    
     $this->addElement('Text', 'duration', array(
      'label' => 'Meeting Duration (in minutes)',
      'allowEmpty' => true,
      'required' => false,
      'validators' => array(
        //array('Empty', true),
      //  array('Min', 30),
       // array('Max', 300),
        array('StringLength', false, array(1, 3)),
      ),
      'filters' => array(
        'StripTags',
        new Engine_Filter_Censor(),
      ),
    ));
    
    
    
    $this->addElement('Text', 'attendee_limit', array(
      'label' => 'Max Attendee',
      'allowEmpty' => true,
      'required' => false,
      'validators' => array(
        //array('Empty', true),
      //  array('Min', 30),
       // array('Max', 300),
      //  array('StringLength', false, array(1, 3)),
      ),
      'filters' => array(
        'StripTags',
        new Engine_Filter_Censor(),
      ),
    ));

    
    //     $this->addElement('Radio', 'control_category_id', array(
    //   'label' => 'Who can attend?',
    //   'multiOptions' => array(
    //     '0' => 'To all visitors and registered users of the academy',
    //     '1' => 'Only to the users you enrol.',
    //   ),
    //   'value' => '1',
    // ));
    
    $this->addElement('Radio', 'set_guest_privacy', array(
      'label' => 'Who Attend this meeting?',
      'multiOptions' => array(
        '0' => 'Guest (Login not required to attend meeting)',
        '1' => 'Registered Members (Login Required to attend meeting)',
        '2' => 'Meeting Room Members (Login Required & Member must join the  Room)'
      ),
      'value' => '0',
    ));
    
    $this->addElement('Radio', 'create_recording', array(
      'label' => 'Record the class?',
      'multiOptions' => array(
        '1' => 'Yes',
        '0' => 'NO',
      ),
      'value' => '1',
    ));
    
    $this->addElement('Select', 'language', array(
       'label' => 'Language',
       'value' => 'en-us',
           'multiOptions' => array(
        'en-us' => 'English',
        'ar-sa' => 'Arabic Saudi Arabia',
    ),
       'tabindex' => $tabIndex++,
     ));
    
        // Element: timezone
    // $this->addElement('Select', 'timezone', array(
    //   'label' => 'Timezone',
    //   'value' => $settings->getSetting('core.locale.timezone'),
    //   'multiOptions' => array(
    //     'US/Pacific' => '(UTC-8) Pacific Time (US & Canada)',
    //     'US/Mountain' => '(UTC-7) Mountain Time (US & Canada)',
    //     'US/Central' => '(UTC-6) Central Time (US & Canada)',
    //     'US/Eastern' => '(UTC-5) Eastern Time (US & Canada)',
    //     'America/Halifax' => '(UTC-4)  Atlantic Time (Canada)',
    //     'America/Anchorage' => '(UTC-9)  Alaska (US & Canada)',
    //     'Pacific/Honolulu' => '(UTC-10) Hawaii (US)',
    //     'Pacific/Samoa' => '(UTC-11) Midway Island, Samoa',
    //     'Etc/GMT-12' => '(UTC-12) Eniwetok, Kwajalein',
    //     'Canada/Newfoundland' => '(UTC-3:30) Canada/Newfoundland',
    //     'America/Buenos_Aires' => '(UTC-3) Brasilia, Buenos Aires, Georgetown',
    //     'Atlantic/South_Georgia' => '(UTC-2) Mid-Atlantic',
    //     'Atlantic/Azores' => '(UTC-1) Azores, Cape Verde Is.',
    //     'Europe/London' => 'Greenwich Mean Time (Lisbon, London)',
    //     'Europe/Berlin' => '(UTC+1) Amsterdam, Berlin, Paris, Rome, Madrid',
    //     'Europe/Athens' => '(UTC+2) Athens, Helsinki, Istanbul, Cairo, E. Europe',
    //     'Europe/Moscow' => '(UTC+3) Baghdad, Kuwait, Nairobi, Moscow',
    //     'Iran' => '(UTC+3:30) Tehran',
    //     'Asia/Dubai' => '(UTC+4) Abu Dhabi, Kazan, Muscat',
    //     'Asia/Kabul' => '(UTC+4:30) Kabul',
    //     'Asia/Yekaterinburg' => '(UTC+5) Islamabad, Karachi, Tashkent',
    //     'Asia/Calcutta' => '(UTC+5:30) Bombay, Calcutta, New Delhi',
    //     'Asia/Katmandu' => '(UTC+5:45) Nepal',
    //     'Asia/Omsk' => '(UTC+6) Almaty, Dhaka',
    //     'Indian/Cocos' => '(UTC+6:30) Cocos Islands, Yangon',
    //     'Asia/Krasnoyarsk' => '(UTC+7) Bangkok, Jakarta, Hanoi',
    //     'Asia/Hong_Kong' => '(UTC+8) Beijing, Hong Kong, Singapore, Taipei',
    //     'Asia/Tokyo' => '(UTC+9) Tokyo, Osaka, Sapporto, Seoul, Yakutsk',
    //     'Australia/Adelaide' => '(UTC+9:30) Adelaide, Darwin',
    //     'Australia/Sydney' => '(UTC+10) Brisbane, Melbourne, Sydney, Guam',
    //     'Asia/Magadan' => '(UTC+11) Magadan, Solomon Is., New Caledonia',
    //     'Pacific/Auckland' => '(UTC+12) Fiji, Kamchatka, Marshall Is., Wellington',
    //   ),
    //   'tabindex' => $tabIndex++,
    // ));
    // $this->timezone->getDecorator('Description')->setOptions(array('placement' => 'APPEND'));

    // Element: language

    // Languages
    $translate = Zend_Registry::get('Zend_Translate');
    $languageList = $translate->getList();

    //$currentLocale = Zend_Registry::get('Locale')->__toString();
    // Prepare default langauge
    $defaultLanguage = Engine_Api::_()->getApi('settings', 'core')->getSetting('core.locale.locale', 'en');
    if( !in_array($defaultLanguage, $languageList) ) {
      if( $defaultLanguage == 'auto' && isset($languageList['en']) ) {
        $defaultLanguage = 'en-us';
      } else {
        $defaultLanguage = null;
      }
    }

    // Prepare language name list
    $localeObject = Zend_Registry::get('Locale');
    
    $languageNameList = array();
    $languageDataList = Zend_Locale_Data::getList($localeObject, 'language');
    $territoryDataList = Zend_Locale_Data::getList($localeObject, 'territory');

    foreach( $languageList as $localeCode ) {
      $languageNameList[$localeCode] = Zend_Locale::getTranslation($localeCode, 'language', $localeCode);
      if( empty($languageNameList[$localeCode]) ) {
        list($locale, $territory) = explode('_', $localeCode);
        $languageNameList[$localeCode] = "{$territoryDataList[$territory]} {$languageDataList[$locale]}";
      }
    }
    $languageNameList = array_merge(array(
      $defaultLanguage => $defaultLanguage
    ), $languageNameList);

$languageNameList['en-us'] = 'English';
unset($languageNameList['en']);
    // if(count($languageNameList)>1){
    //   $this->addElement('Select', 'language', array(
    //     'label' => 'Language',
    //     'multiOptions' => $languageNameList,
    //     'tabindex' => $tabIndex++,
    //   ));
    //   $this->language->getDecorator('Description')->setOptions(array('placement' => 'APPEND'));
    // }
    // else{
    //   $this->addElement('Hidden', 'language', array(
    //     'value' => current((array)$languageNameList),
    //     'order' => 1002
    //   ));
    // }
    //  $this->addElement('Hidden', 'language', array(
    //     'value' => 'en-us',
    //     'order' => 1002
    //   ));
  //  $this->duration->setAttribute('min', 30);

// 		$requestParameters["duration"]=""; //optional
// 		$requestParameters["time_zone"]="Asia/Kolkata"; //optional
// 		$requestParameters["attendee_limit"]=""; //optional
// 		$requestParameters["control_category_id"]=""; //optional
// 		$requestParameters["create_recording"]=""; //optional
// 		$requestParameters["return_url"]=""; //optional
// 		$requestParameters["status_ping_url"]=""; //optional
//         $requestParameters["language_culture_name"]="en-us";
    // Buttons
    $this->addElement('Button', 'submit', array(
      'label' => 'Save Changes',
      'type' => 'submit',
      'ignore' => true,
      'decorators' => array(
        'ViewHelper',
      ),
    ));

    $this->addElement('Cancel', 'cancel', array(
      'label' => 'cancel',
      'link' => true,
      'prependText' => ' or ',
      'decorators' => array(
        'ViewHelper',
      ),
    ));

    $this->addDisplayGroup(array('submit', 'cancel'), 'buttons', array(
      'decorators' => array(
        'FormElements',
        'DivDivDivWrapper',
      ),
    ));
  }
}