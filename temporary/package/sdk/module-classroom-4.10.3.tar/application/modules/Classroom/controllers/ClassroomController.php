<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: ClassroomController.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */

require_once("create.php");
require_once("ModifyClass.php"); 
require_once("AddAttendee.php");
require_once("DeleteClass.php"); 
require_once("CancelClass.php"); 
class Classroom_ClassroomController extends Core_Controller_Action_Standard
{
  public function init()
  {
    if( 0 !== ($classroom_id = (int) $this->_getParam('classroom_id')) &&
        null !== ($classroom = Engine_Api::_()->getItem('classroom', $classroom_id)) ) {
      Engine_Api::_()->core()->setSubject($classroom);
    } 

    $this->_helper->requireUser();
    $this->_helper->requireSubject('classroom');
  }
  
    public function liveCancelClassAction()
  {

    $viewer = Engine_Api::_()->user()->getViewer();
    $classroom = Engine_Api::_()->getItem('classroom', $this->getRequest()->getParam('classroom_id'));
    

    // In smoothbox
    $this->_helper->layout->setLayout('default-simple');
    
    // Make form
    $this->view->form = $form = new Classroom_Form_LiveClassCancel();

    if( !$classroom )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_("Class doesn't exists or not authorized to cancel");
      return;
    }

    if( !$this->getRequest()->isPost() )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
      return;
    }

    

    try
    {
       
        $secretAcessKey = '1ZJxaO3FB95iq18o9tfJiQ==';
        $access_key = 'vNBHxdarp4o=';
        $webServiceUrl="http://classapi.wiziqxt.com/apimanager.ashx";
        $values= array();
        $values['class_id'] = $classroom->class_id;
        $values['class_master_id'] = $classroom->class_master_id;
        $obj=new CancelClass($secretAcessKey,$access_key,$webServiceUrl, $values);	
                // check dates
    if( isset($obj->object['error_code']) ) {
      $form->setErrors(array($obj->object['error_msg']));
      return;
    }
      //$classroom->delete();
    
    }
    catch( Exception $e )
    {
      
      throw $e;
    }
    $this->view->status = true;
    $this->view->message = Zend_Registry::get('Zend_Translate')->_('The selected class has been cancelled.');
    return $this->_forward('success' ,'utility', 'core', array(
      'parentRedirect' => Zend_Controller_Front::getInstance()->getRouter()->assemble(array('id' => Engine_Api::_()->core()->getSubject()->parent_id), 'classroom_profile', true),
      'messages' => Array($this->view->message)
    ));
  }
  
  public function shareClassAction() {
      $this->_helper->layout->setLayout('default-simple');
  }
  
  public function liveDeleteClassAction()
  {

    $viewer = Engine_Api::_()->user()->getViewer();
    $classroom = Engine_Api::_()->getItem('classroom', $this->getRequest()->getParam('classroom_id'));
    if( !$this->_helper->requireAuth()->setAuthParams($classroom, null, 'delete')->isValid()) return;

    // In smoothbox
    $this->_helper->layout->setLayout('default-simple');
    
    // Make form
    $this->view->form = $form = new Classroom_Form_LiveClassDelete();

    if( !$classroom )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_("Class doesn't exists or not authorized to delete");
      return;
    }

    if( !$this->getRequest()->isPost() )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
      return;
    }

    

    try
    {
       
        $secretAcessKey = '1ZJxaO3FB95iq18o9tfJiQ==';
        $access_key = 'vNBHxdarp4o=';
        $webServiceUrl="http://contentapi.wiziqxt.com/RestService.ashx/";
        $values= array();
        $values['content_id'] = $classroom->class_id;
        $values['class_id'] = $classroom->class_id;
        $values['class_master_id'] = $classroom->class_master_id;
        $obj=new DeleteClass($secretAcessKey,$access_key,$webServiceUrl, $values);	
        
      $classroom->delete();
    
    }
    catch( Exception $e )
    {
      
      throw $e;
    }
    $this->view->status = true;
    $this->view->message = Zend_Registry::get('Zend_Translate')->_('The selected class has been deleted.');
    return $this->_forward('success' ,'utility', 'core', array(
      'parentRedirect' => Zend_Controller_Front::getInstance()->getRouter()->assemble(array('id' => Engine_Api::_()->core()->getSubject()->parent_id), 'classroom_profile', true),
      'messages' => Array($this->view->message)
    ));
  }
  
  public function liveJoinClassAction() {
        $classroom = Engine_Api::_()->core()->getSubject();
        $viewer = Engine_Api::_()->user()->getViewer();
        $secretAcessKey = '1ZJxaO3FB95iq18o9tfJiQ==';
        $access_key = 'vNBHxdarp4o=';
        $webServiceUrl="http://classapi.wiziqxt.com/apimanager.ashx";
        $values= array();
        $values['class_id'] = $classroom->class_id;
        $values['title'] = $viewer->getTitle();
        
        $values['id'] = $viewer->getIdentity();
        $obj=new AddAttendee($secretAcessKey,$access_key,$webServiceUrl, $values);	

      //  check dates
        if( isset($obj->object['error_code']) ) {
           return $this->_helper->redirector->gotoRoute(array('id' => Engine_Api::_()->core()->getSubject()->parent_id), 'classroom_profile', true);
        }
    $db = Engine_Api::_()->getDbtable('attendee', 'classroom')->getAdapter();
    $db->beginTransaction();
        try { 
          // Create classroom
          $values['attendee_master_id'] = $obj->object['attendee_id'];
          $values['attendee_url'] = $obj->object['attendee_url'];
          $values['class_id'] = $classroom->class_id;
          $values['add_attendeesStatus'] = $obj->object['add_attendeesStatus'];
          $values['user_id'] =$viewer->getIdentity();
          $table = Engine_Api::_()->getDbtable('attendee', 'classroom');
          $attendee = $table->createRow();
          $attendee->setFromArray($values);
          $attendee->save();
// Commit
      $db->commit();

        header("Location: ". $values['attendee_url']);
      // Redirect
      //return $this->_helper->redirector->gotoRoute(array('id' => Engine_Api::_()->core()->getSubject()->parent_id), 'classroom_profile', true);
    } catch( Exception $e ) {
      return $this->exceptionWrapper($e);
    }
        
  }
  
//   public function liveCancelClassAction()
//   {
//     $classroom = Engine_Api::_()->core()->getSubject();
//     $this->view->form = $form = new Classroom_Form_LiveClassCancel();
//   }

  public function liveEditClassAction()
  {
    $classroom = Engine_Api::_()->core()->getSubject();
    $officerList = $classroom->getOfficerList();
    $this->view->form = $form = new Classroom_Form_LiveClassEdit();

 

    if( !$this->getRequest()->isPost() ) {
 

      $form->populate($classroom->toArray());
       $start = strtotime($classroom->starttime);
      
      $start = date('Y-m-d H:i:s', $start);
     

      $form->populate(array(
        'starttime' => $start
      ));
      return;
    }

    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }
    $values = $form->getValues();
    $values['parent_type'] = 'classroom';
    $values['parent_id'] = $classroom->parent_id;
    $secretAcessKey = '1ZJxaO3FB95iq18o9tfJiQ==';
    $access_key = 'vNBHxdarp4o=';
    $webServiceUrl="http://classapi.wiziqxt.com/apimanager.ashx";
	
    
        // Convert times
    //$oldTz = date_default_timezone_get();
    //date_default_timezone_set($viewer->timezone);
    $start = strtotime($values['starttime']);
    //date_default_timezone_set($oldTz);
    $values['starttime'] = date('Y-m-d H:i:s', $start);
    $viewer = Engine_Api::_()->user()->getViewer();
    $values['user_id'] = $viewer->getIdentity();
    $values['class_id'] = $classroom->class_id;
    $values['class_master_id'] = $classroom->class_master_id;
     
    
    $obj=new ModifyClass($secretAcessKey,$access_key,$webServiceUrl, $values);	

    
        // check dates
    if( isset($obj->object['error_code']) ) {
      $form->title->setErrors(array($obj->object['error_msg']));
      return;
    }
    
     
    $values['auth_view'] = 'everyone';
    

      $values['auth_comment'] = 'everyone';
    
    $values['view_privacy'] =  $values['auth_view'];

    $db = Engine_Api::_()->getDbtable('classrooms', 'classroom')->getAdapter();
    $db->beginTransaction();

    try { 
    
      $classroom->setFromArray($values);
      $classroom->save();



      // Commit
      $db->commit();

      // Redirect
      return $this->_helper->redirector->gotoRoute(array('id' => Engine_Api::_()->core()->getSubject()->getIdentity()), 'classroom_profile', true);
    } catch( Exception $e ) {
      return $this->exceptionWrapper($e, $form, $db);
    }
  }     
   
  public function liveClassAction()
  {
    if( !$this->_helper->requireUser->isValid() )
        return;
    if( !$this->_helper->requireAuth()->setAuthParams('classroom', null, 'create')->isValid() )
        return;

    // Create form
    $this->view->form = $form = new Classroom_Form_LiveClassCreate();
    $viewer = Engine_Api::_()->user()->getViewer();
    // Check method/data validitiy
    if( !$this->getRequest()->isPost() ) {
      return;
    }

    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }
    $values = $form->getValues();
    $values['parent_type'] = 'classroom';
    $values['parent_id'] = Engine_Api::_()->core()->getSubject()->getIdentity();
    $secretAcessKey = '1ZJxaO3FB95iq18o9tfJiQ==';
    $access_key = 'vNBHxdarp4o=';
    $webServiceUrl="http://classapi.wiziqxt.com/apimanager.ashx";
	
    
        // Convert times
    //$oldTz = date_default_timezone_get();
    //date_default_timezone_set($viewer->timezone);
    $start = strtotime($values['starttime']);
    //date_default_timezone_set($oldTz);
    $values['starttime'] = date('Y-m-d H:i:s', $start);
    $viewer = Engine_Api::_()->user()->getViewer();
    $values['user_id'] = $viewer->getIdentity();
    $values['name'] = $viewer->getTitle();
    
    
    $obj=new ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $values, Engine_Api::_()->core()->getSubject());	

    
        // check dates
    if( isset($obj->object['error_code']) ) {
      $form->title->setErrors(array($obj->object['error_msg']));
      return;
    }
    
    
    $values['class_id'] = $obj->object['class_id'];
    $values['class_master_id'] = $obj->object['class_master_id'];
    
    // $values['recording_url'] = $obj->object['recording_url'];
    // $values['presenter_url'] = $obj->object['presenter_url'];
    // $values['presenter_email'] = $obj->object['presenter_email'];
    $values['auth_view'] = 'everyone';
    

      $values['auth_comment'] = 'everyone';
    
    $values['view_privacy'] =  $values['auth_view'];

    $db = Engine_Api::_()->getDbtable('classrooms', 'classroom')->getAdapter();
    $db->beginTransaction();

    try { 
      // Create classroom
      $table = Engine_Api::_()->getDbtable('classrooms', 'classroom');
      $classroom = $table->createRow();
      $classroom->setFromArray($values);
      $classroom->save();

      // Add owner as member
      $classroom->membership()->addMember($viewer)
          ->setUserApproved($viewer)
          ->setResourceApproved($viewer);


      // Process privacy
      $auth = Engine_Api::_()->authorization()->context;
      
      $roles = array('officer', 'member', 'registered', 'everyone');

      $viewMax = array_search($values['auth_view'], $roles);
      $commentMax = array_search($values['auth_comment'], $roles);

      $officerList = $classroom->getOfficerList();

      foreach( $roles as $i => $role ) {
        if( $role === 'officer' ) {
          $role = $officerList;
        }
        $auth->setAllowed($classroom, $role, 'view', ($i <= $viewMax));
        $auth->setAllowed($classroom, $role, 'comment', ($i <= $commentMax));
      }
      
      // Create some auth stuff for all officers
      $auth->setAllowed($classroom, $officerList, 'photo.edit', 1);
      $auth->setAllowed($classroom, $officerList, 'topic.edit', 1);

      // Add auth for invited users
      $auth->setAllowed($classroom, 'member_requested', 'view', 1);



    
            
        
        $values['title'] = $viewer->getTitle();
        $values['id'] = $viewer->getIdentity();
        // $obj=new AddAttendee($secretAcessKey,$access_key,$webServiceUrl, $values);	
        // $db = Engine_Api::_()->getDbtable('attendee', 'classroom')->getAdapter();
        // $db->beginTransaction();
        //     try { 
        //       // Create classroom
        //       $values['attendee_master_id'] = $obj->object['attendee_id'];
        //       $values['attendee_url'] = $obj->object['attendee_url'];
        //       $values['class_id'] = $classroom->class_id;
        //       $values['add_attendeesStatus'] = $obj->object['add_attendeesStatus'];
        //       $values['user_id'] =$viewer->getIdentity();
        //       $table = Engine_Api::_()->getDbtable('attendee', 'classroom');
        //       $attendee = $table->createRow();
        //       $attendee->setFromArray($values);
        //       $attendee->save();
    
        //   $db->commit();
    
        //   // Redirect
        // } catch( Exception $e ) {
        // }


      // Commit
      $db->commit();

      // Redirect
      return $this->_helper->redirector->gotoRoute(array('id' => Engine_Api::_()->core()->getSubject()->getIdentity()), 'classroom_profile', true);
    } catch( Exception $e ) {
      return $this->exceptionWrapper($e, $form, $db);
    }
  } 
  public function editAction()
  {
    if( !$this->_helper->requireAuth()->setAuthParams(null, null, 'edit')->isValid() ) {
      return;
    }

    $classroom = Engine_Api::_()->core()->getSubject();
    $officerList = $classroom->getOfficerList();
    $this->view->form = $form = new Classroom_Form_Edit();

    // Populate with categories
    $categories = Engine_Api::_()->getDbtable('categories', 'classroom')->getCategoriesAssoc();
    asort($categories, SORT_LOCALE_STRING);
    $categoryOptions = array('0' => '');
    foreach( $categories as $k => $v ) {
      $categoryOptions[$k] = $v;
    }
    $form->category_id->setMultiOptions($categoryOptions);

    if( count($form->category_id->getMultiOptions()) <= 1 ) {
      $form->removeElement('category_id');
    }

    if( !$this->getRequest()->isPost() ) {
      // Populate auth
      $auth = Engine_Api::_()->authorization()->context;
      $roles = array('officer', 'member', 'registered', 'everyone');
      $actions = array('view', 'comment', 'invite', 'photo', 'event');
      $perms = array();
      foreach( $roles as $roleString ) {
        $role = $roleString;
        if( $role === 'officer' ) {
          $role = $officerList;
        }
        foreach( $actions as $action ) {
          if( $auth->isAllowed($classroom, $role, $action) ) {
            $perms['auth_' . $action] = $roleString;
          }
        }
      }

      $form->populate($classroom->toArray());
      $form->populate($perms);
      return;
    }

    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }

    // Process
    $db = Engine_Api::_()->getItemTable('classroom')->getAdapter();
    $db->beginTransaction();

    try {
      $values = $form->getValues();

      if( empty($values['auth_view']) ) {
        $values['auth_view'] = 'everyone';
      }

      if( empty($values['auth_comment']) ) {
        $values['auth_comment'] = 'everyone';
      }

      $values['view_privacy'] =  $values['auth_view'];

      // Set classroom info
      $classroom->setFromArray($values);
      $classroom->save();

      if( !empty($values['photo']) ) {
        $classroom->setPhoto($form->photo);
      }

      // Process privacy
      $auth = Engine_Api::_()->authorization()->context;

      $roles = array('officer', 'member', 'registered', 'everyone');

      $viewMax = array_search($values['auth_view'], $roles);
      $commentMax = array_search($values['auth_comment'], $roles);
      $photoMax = array_search($values['auth_photo'], $roles);
      $eventMax = array_search($values['auth_event'], $roles);
      $inviteMax = array_search($values['auth_invite'], $roles);

      foreach( $roles as $i => $role ) {
        if( $role === 'officer' ) {
          $role = $officerList;
        }
        $auth->setAllowed($classroom, $role, 'view', ($i <= $viewMax));
        $auth->setAllowed($classroom, $role, 'comment', ($i <= $commentMax));
        $auth->setAllowed($classroom, $role, 'photo', ($i <= $photoMax));
        $auth->setAllowed($classroom, $role, 'event', ($i <= $eventMax));
        $auth->setAllowed($classroom, $role, 'invite', ($i <= $inviteMax));
      }

      // Create some auth stuff for all officers
      $auth->setAllowed($classroom, $officerList, 'photo.edit', 1);
      $auth->setAllowed($classroom, $officerList, 'topic.edit', 1);

      // Add auth for invited users
      $auth->setAllowed($classroom, 'member_requested', 'view', 1);
      
      // Commit
      $db->commit();
    } catch( Engine_Image_Exception $e ) {
      $db->rollBack();
      $form->addError(Zend_Registry::get('Zend_Translate')->_('The image you selected was too large.'));
    } catch( Exception $e ) {
      $db->rollBack();
      throw $e;
    }


    $db->beginTransaction();
    try {
      // Rebuild privacy
      $actionTable = Engine_Api::_()->getDbtable('actions', 'activity');
      foreach( $actionTable->getActionsByObject($classroom) as $action ) {
        $actionTable->resetActivityBindings($action);
      }

      $db->commit();
    }
    catch( Exception $e )
    {
      $db->rollBack();
      throw $e;
    }



    // Redirect
    if( $this->_getParam('ref') === 'profile' ) {
      $this->_redirectCustom($classroom);
    } else {
      $this->_redirectCustom(array('route' => 'classroom_general', 'action' => 'manage'));
    }
  }

  public function deleteAction()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $classroom = Engine_Api::_()->getItem('classroom', $this->getRequest()->getParam('classroom_id'));
    if( !$this->_helper->requireAuth()->setAuthParams($classroom, null, 'delete')->isValid()) return;

    // In smoothbox
    $this->_helper->layout->setLayout('default-simple');
    
    // Make form
    $this->view->form = $form = new Classroom_Form_Delete();
    
    if( !$classroom )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_("Classroom doesn't exists or not authorized to delete");
      return;
    }

    if( !$this->getRequest()->isPost() )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
      return;
    }

    $db = $classroom->getTable()->getAdapter();
    $db->beginTransaction();

    try {
      $classroom->delete();

      $db->commit();
    } catch( Exception $e ) {
      $db->rollBack();
      throw $e;
    }

    $this->view->status = true;
    $this->view->message = Zend_Registry::get('Zend_Translate')->_('The selected classroom has been deleted.');
    return $this->_forward('success' ,'utility', 'core', array(
      'parentRedirect' => Zend_Controller_Front::getInstance()->getRouter()->assemble(array('action' => 'manage'), 'classroom_general', true),
      'messages' => Array($this->view->message)
    ));
  }

  public function styleAction()
  {
    if( !$this->_helper->requireAuth()->setAuthParams(null, null, 'edit')->isValid() )
        return;
    if( !$this->_helper->requireAuth()->setAuthParams(null, null, 'style')->isValid() )
        return;

    $user = Engine_Api::_()->user()->getViewer();
    $classroom = Engine_Api::_()->core()->getSubject('classroom');

    // Make form
    $this->view->form = $form = new Classroom_Form_Style();

    // Get current row
    $table = Engine_Api::_()->getDbtable('styles', 'core');
    $select = $table->select()
            ->where('type = ?', 'classroom')
            ->where('id = ?', $classroom->getIdentity())
            ->limit(1);

    $row = $table->fetchRow($select);

    // Check post
    if( !$this->getRequest()->isPost() ) {
      $form->populate(array(
        'style' => ( null === $row ? '' : $row->style )
      ));
      return;
    }

    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }

    // Cool! Process
    $style = $form->getValue('style');

    // Save
    if( null == $row ) {
      $row = $table->createRow();
      $row->type = 'classroom';
      $row->id = $classroom->getIdentity();
    }

    $row->style = $style;
    $row->save();

    $this->view->draft = true;
    $this->view->message = Zend_Registry::get('Zend_Translate')->_('Your changes have been saved.');
    $this->_forward('success', 'utility', 'core', array(
      'smoothboxClose' => true,
      'parentRefresh' => false,
      'messages' => array(Zend_Registry::get('Zend_Translate')->_('Your changes have been saved.'))
    ));
  }

}