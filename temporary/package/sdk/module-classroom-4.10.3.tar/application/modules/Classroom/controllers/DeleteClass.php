<?php
class DeleteClass
{
		var $object;
	function DeleteClass($secretAcessKey,$access_key,$webServiceUrl, $values)
	{
	    
		require_once("AuthBase.php");
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$method = "delete";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		$requestParameters["content_id"] = $values['content_id'];
		$requestParameters["class_id"] = $values['class_id'];
		
		$httpRequest=new HttpRequest();
		try
		{
			$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=delete',http_build_query($requestParameters, '', '&')); 
		}
		catch(Exception $e)
		{	
	  		echo $e->getMessage();
		}
	
		
 		if(!empty($XMLReturn))
 		{
 			try
			{
			  $objDOM = new DOMDocument();
			  $objDOM->loadXML($XMLReturn);
	  
			}
			catch(Exception $e)
			{
			  echo $e->getMessage();
			}
			
			$status=$objDOM->getElementsByTagName("rsp")->item(0);
    		$attribNode = $status->getAttribute("status");
    		
			if($attribNode=="ok")
			{

			}
			else if($attribNode=="fail")
			{
				$error=$objDOM->getElementsByTagName("error")->item(0);
			$values['error_code'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("code");
			$values['error_msg'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("msg");
			}
			
			$this->object =$values;
	 	}//end if	
   }//end function
	
}
?>