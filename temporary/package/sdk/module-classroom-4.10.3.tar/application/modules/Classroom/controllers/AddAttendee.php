<?php
class AddAttendee
{
	var $object;
	function AddAttendee($secretAcessKey,$access_key,$webServiceUrl, $values)
	{
		require_once("AuthBase.php");
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$XMLAttendee="<attendee_list>
			<attendee>
			  <attendee_id>".$values['id']."</attendee_id>
			  <screen_name>".$values['title']."</screen_name>
                          <language_culture_name>en-us</language_culture_name>
			</attendee>
		  </attendee_list>";
		$method = "add_attendees";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		$requestParameters["class_id"] = $values['class_id'];//required
		$requestParameters["attendee_list"]=$XMLAttendee;
		$httpRequest=new HttpRequest();
		try
		{
			$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=add_attendees',http_build_query($requestParameters, '', '&')); 
		}
		catch(Exception $e)
		{	
	  		echo $e->getMessage();
		}
	
 		if(!empty($XMLReturn))
 		{
 			try
			{
			  $objDOM = new DOMDocument();
			  $objDOM->loadXML($XMLReturn);
			}
			catch(Exception $e)
			{
			  echo $e->getMessage();
			}
			$status=$objDOM->getElementsByTagName("rsp")->item(0);
    		$attribNode = $status->getAttribute("status");
    		$values = array();
			if($attribNode=="ok")
			{
				$methodTag=$objDOM->getElementsByTagName("method");
				//echo "<br>method=".$method=$methodTag->item(0)->nodeValue;
				
				$class_idTag=$objDOM->getElementsByTagName("class_id");
				//echo "<br>class_id=".$class_id=$class_idTag->item(0)->nodeValue;
			    $values['class_id'] = $class_id;
				$add_attendeesTag=$objDOM->getElementsByTagName("add_attendees")->item(0);
			//	echo "<br>add_attendeesStatus=".$add_attendeesStatus = $add_attendeesTag->getAttribute("status");
				$values['add_attendeesStatus'] = $add_attendeesTag->getAttribute("status");
				$attendeeTag=$objDOM->getElementsByTagName("attendee");
				$length=$attendeeTag->length;
				for($i=0;$i<$length;$i++)
				{
					$attendee_idTag=$objDOM->getElementsByTagName("attendee_id");
					//echo "<br>attendee_id=".$attendee_id=$attendee_idTag->item($i)->nodeValue;
					$values['attendee_id'] = $attendee_idTag->item($i)->nodeValue;
					$attendee_urlTag=$objDOM->getElementsByTagName("attendee_url");
					//echo "<br>attendee_url=".$attendee_url=$attendee_urlTag->item($i)->nodeValue;
					$values['attendee_url'] = $attendee_urlTag->item($i)->nodeValue;
				}
 			}
			else if($attribNode=="fail")
			{
					$error=$objDOM->getElementsByTagName("error")->item(0);
        			$values['error_code'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("code");
        			$values['error_msg'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("msg");	
			}
			
			$this->object = $values;
	 	}//end if	
   }//end function
	
}
?>