<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: IndexController.php 10265 2014-06-06 22:11:31Z lucas $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_IndexController extends Core_Controller_Action_Standard
{
  public function init()
  {

    if( !$this->_helper->requireAuth()->setAuthParams('classroom', null, 'view')->isValid() )
        return;

    $id = $this->_getParam('classroom_id', $this->_getParam('id', null));
    if( $id ) {
      $classroom = Engine_Api::_()->getItem('classroom', $id);
      if( $classroom ) {
        Engine_Api::_()->core()->setSubject($classroom);
      }
    }
  }

  public function browseAction()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    
    // Check create
    $this->view->canCreate = Engine_Api::_()->authorization()->isAllowed('classroom', null, 'create');
    
    // Form
    $this->view->formFilter = $formFilter = new Classroom_Form_Filter_Browse();
    $defaultValues = $formFilter->getValues();

    if( !$viewer || !$viewer->getIdentity() ) {
      $formFilter->removeElement('view');
    }

    // Populate options
    $categories = Engine_Api::_()->getDbtable('categories', 'classroom')->getCategoriesAssoc();
    $formFilter->category_id->addMultiOptions($categories);

    // Populate form data
    if( $formFilter->isValid($this->_getAllParams()) ) {
      $this->view->formValues = $values = $formFilter->getValues();
    } else {
      $formFilter->populate($defaultValues);
      $this->view->formValues = $values = array();
    }

    // Prepare data
    $this->view->formValues = $values = $formFilter->getValues();

    if( $viewer->getIdentity() && @$values['view'] == 1 ) {
      $values['users'] = array();
      foreach( $viewer->membership()->getMembersInfo(true) as $memberinfo ) {
        $values['users'][] = $memberinfo->user_id;
      }
    }

    $values['search'] = 1;

    // check to see if request is for specific user's listings
    $user_id = $this->_getParam('user');
    if( $user_id ) {
      $values['user_id'] = $user_id;
    }

    
    // Make paginator
    $this->view->paginator = $paginator = Engine_Api::_()->getItemTable('classroom')
            ->getClassroomPaginator($values);

    $paginator->setCurrentPageNumber($this->_getParam('page'));

    // Render
    $this->_helper->content
        //->setNoRender()
        ->setEnabled()
        ;
  }

  public function createAction()
  {
    if( !$this->_helper->requireUser->isValid() )
        return;
    if( !$this->_helper->requireAuth()->setAuthParams('classroom', null, 'create')->isValid() )
        return;

    // Render
    $this->_helper->content
        //->setNoRender()
        ->setEnabled()
        ;


    // set up data needed to check quota
    $viewer = Engine_Api::_()->user()->getViewer();
    $values['user_id'] = $viewer->getIdentity();
    $paginator = Engine_Api::_()->getItemTable('classroom')->getClassroomPaginator($values);

    $this->view->quota = $quota = Engine_Api::_()->authorization()->getPermission($viewer->level_id, 'classroom', 'max');
    $this->view->current_count = $paginator->getTotalItemCount();


    //$this->view->quota = $quota = Engine_Api::_()->authorization()->getPermission($viewer->level_id, 'classroom', 'max');

    // Create form
    $this->view->form = $form = new Classroom_Form_Create();

    // Populate with categories
    $categories = Engine_Api::_()->getDbtable('categories', 'classroom')->getCategoriesAssoc();
    asort($categories, SORT_LOCALE_STRING);
    $categoryOptions = array('0' => '');
    foreach( $categories as $k => $v ) {
      $categoryOptions[$k] = $v;
    }
    $form->category_id->setMultiOptions($categoryOptions);

    if( count($form->category_id->getMultiOptions()) <= 1 ) {
      $form->removeElement('category_id');
    }

    // Check method/data validitiy
    if( !$this->getRequest()->isPost() ) {
      return;
    }

    if( !$form->isValid($this->getRequest()->getPost()) ) {
      return;
    }

     if( $this->getRequest()->isPost()&& $form->isValid($this->getRequest()->getPost()))
    {
    // Process
    $values = $form->getValues();
    $viewer = Engine_Api::_()->user()->getViewer();
    $values['user_id'] = $viewer->getIdentity();

    if( empty($values['auth_view']) ) {
      $values['auth_view'] = 'everyone';
    }

    if( empty($values['auth_comment']) ) {
      $values['auth_comment'] = 'everyone';
    }

    $values['view_privacy'] =  $values['auth_view'];

    $db = Engine_Api::_()->getDbtable('classrooms', 'classroom')->getAdapter();
    $db->beginTransaction();

    try {
      // Create classroom
      $table = Engine_Api::_()->getDbtable('classrooms', 'classroom');
      $classroom = $table->createRow();
      
      if($viewer->level_id == 1) {
          $values['approved'] = 1;
      } else {
          $values['approved'] = 0;
      }
      
      $classroom->setFromArray($values);
      $classroom->save();

      // Add owner as member
      $classroom->membership()->addMember($viewer)
          ->setUserApproved($viewer)
          ->setResourceApproved($viewer);

      // Set photo
      if( !empty($values['photo']) ) {
        $classroom->setPhoto($form->photo);
      }

      // Process privacy
      $auth = Engine_Api::_()->authorization()->context;
      
      $roles = array('officer', 'member', 'registered', 'everyone');

      $viewMax = array_search($values['auth_view'], $roles);
      $commentMax = array_search($values['auth_comment'], $roles);
      $photoMax = array_search($values['auth_photo'], $roles);
      $eventMax = array_search($values['auth_event'], $roles);
      $inviteMax = array_search($values['auth_invite'], $roles);

      $officerList = $classroom->getOfficerList();

      foreach( $roles as $i => $role ) {
        if( $role === 'officer' ) {
          $role = $officerList;
        }
        $auth->setAllowed($classroom, $role, 'view', ($i <= $viewMax));
        $auth->setAllowed($classroom, $role, 'comment', ($i <= $commentMax));
        $auth->setAllowed($classroom, $role, 'photo', ($i <= $photoMax));
        $auth->setAllowed($classroom, $role, 'event', ($i <= $eventMax));
        $auth->setAllowed($classroom, $role, 'invite', ($i <= $inviteMax));
      }
      
      // Create some auth stuff for all officers
      $auth->setAllowed($classroom, $officerList, 'photo.edit', 1);
      $auth->setAllowed($classroom, $officerList, 'topic.edit', 1);

      // Add auth for invited users
      $auth->setAllowed($classroom, 'member_requested', 'view', 1);

      // Add action
      if($values['approved'] == 1) {
          $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');
          $action = $activityApi->addActivity($viewer, $classroom, 'classroom_create');
          if( $action ) {
            $activityApi->attachActivity($action, $classroom);
          }
      }
      
      // Commit
      $db->commit();

      // Redirect
      
      if($values['approved']) {
          return $this->_helper->redirector->gotoRoute(array('id' => $classroom->getIdentity()), 'classroom_profile', true);
      } else {
          //$form->setAttribs(array('style'=>'display:none'));
          $this->view->formSubmit = true;
          $form->addNotice('Your request for creating the office registered successfully. Once admin will approve this request, then you will be able to see your office.');
      }
      
      
    } catch( Exception $e ) {
      return $this->exceptionWrapper($e, $form, $db);
    }
    }
  }

  public function listAction()
  {
    
  }

  public function manageAction()
  {
    // Render
    $this->_helper->content
        //->setNoRender()
        ->setEnabled()
        ;
    
    // Form
    $this->view->formFilter = $formFilter = new Classroom_Form_Filter_Manage();
    $this->view->formValues = $defaultValues = $formFilter->getValues();

    // Populate form data
    if( $formFilter->isValid($this->_getAllParams()) ) {
      $this->view->formValues = $values = $formFilter->getValues();
    } else {
      $formFilter->populate($defaultValues);
      $this->view->formValues = $values = array();
    }

    $viewer = Engine_Api::_()->user()->getViewer();
    $membership = Engine_Api::_()->getDbtable('membership', 'classroom');
    $select = $membership->getMembershipsOfSelect($viewer);
    $select->where('classroom_id IS NOT NULL');

    $table = Engine_Api::_()->getItemTable('classroom');
    $tName = $table->info('name');
    if( $values['view'] == 2 ) {
      $select->where("`{$tName}`.`user_id` = ?", $viewer->getIdentity());
    }
    if( !empty($values['text']) ) {
      $select->where(
          $table->getAdapter()->quoteInto("`{$tName}`.`title` LIKE ?", '%' . $values['text'] . '%') . ' OR ' .
          $table->getAdapter()->quoteInto("`{$tName}`.`description` LIKE ?", '%' . $values['text'] . '%')
      );
    }

    $this->view->paginator = $paginator = Zend_Paginator::factory($select);
    $this->view->text = $values['text'];
    $this->view->view = $values['view'];
    $paginator->setCurrentPageNumber($this->_getParam('page'));

    // Check create
    $this->view->canCreate = Engine_Api::_()->authorization()->isAllowed('classroom', null, 'create');
  }
  public function uploadPhotoAction()
  {
    $viewer = Engine_Api::_()->user()->getViewer();

    $this->_helper->layout->disableLayout();

    if( !Engine_Api::_()->authorization()->isAllowed('album', $viewer, 'create') ) {
      return false;
    }

    if( !$this->_helper->requireAuth()->setAuthParams('album', null, 'create')->isValid() ) return;

    if( !$this->_helper->requireUser()->checkRequire() )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('Max file size limit exceeded (probably).');
      return;
    }

    if( !$this->getRequest()->isPost() )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid request method');
      return;
    }
    if( !isset($_FILES['userfile']) || !is_uploaded_file($_FILES['userfile']['tmp_name']) )
    {
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('Invalid Upload');
      return;
    }

    $db = Engine_Api::_()->getDbtable('photos', 'album')->getAdapter();
    $db->beginTransaction();

    try
    {
      $viewer = Engine_Api::_()->user()->getViewer();

      $photoTable = Engine_Api::_()->getDbtable('photos', 'album');
      $photo = $photoTable->createRow();
      $photo->setFromArray(array(
        'owner_type' => 'user',
        'owner_id' => $viewer->getIdentity()
      ));
      $photo->save();

      $photo->setPhoto($_FILES['userfile']);

      $this->view->status = true;
      $this->view->name = $_FILES['userfile']['name'];
      $this->view->photo_id = $photo->photo_id;
      $this->view->photo_url = $photo->getPhotoUrl();

      $table = Engine_Api::_()->getDbtable('albums', 'album');
      $album = $table->getSpecialAlbum($viewer, 'classroom');

      $photo->album_id = $album->album_id;
      $photo->save();

      if( !$album->photo_id )
      {
        $album->photo_id = $photo->getIdentity();
        $album->save();
      }

      $auth      = Engine_Api::_()->authorization()->context;
      $auth->setAllowed($photo, 'everyone', 'view',    true);
      $auth->setAllowed($photo, 'everyone', 'comment', true);
      $auth->setAllowed($album, 'everyone', 'view',    true);
      $auth->setAllowed($album, 'everyone', 'comment', true);


      $db->commit();

    } catch( Album_Model_Exception $e ) {
      $db->rollBack();
      $this->view->status = false;
      $this->view->error = $this->view->translate($e->getMessage());
      throw $e;
      return;

    } catch( Exception $e ) {
      $db->rollBack();
      $this->view->status = false;
      $this->view->error = Zend_Registry::get('Zend_Translate')->_('An error occurred.');
      throw $e;
      return;
    }
  }

}
