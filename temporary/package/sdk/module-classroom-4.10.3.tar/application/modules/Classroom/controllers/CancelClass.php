<?php
class CancelClass
{
	var $object;
	function CancelClass($secretAcessKey,$access_key,$webServiceUrl, $values)
	{
		require_once("AuthBase.php");
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$method = "cancel";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		$requestParameters["class_id"] = $values['class_id'];
		$requestParameters["class_master_id"] = $values['class_master_id'];
		
		$httpRequest=new HttpRequest();
		try
		{
			$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=cancel',http_build_query($requestParameters, '', '&')); 
		}
		catch(Exception $e)
		{	
	  		echo $e->getMessage();
		} 
		
 		if(!empty($XMLReturn))
 		{
 			try
			{
			  $objDOM = new DOMDocument();
			  $objDOM->loadXML($XMLReturn);
			}
			catch(Exception $e)
			{
			  echo $e->getMessage();
			}
			$status=$objDOM->getElementsByTagName("rsp")->item(0);
    		$attribNode = $status->getAttribute("status");
			if($attribNode=="ok")
			{
			    $values['status'] = $objDOM->getElementsByTagName("status")->item(0)->nodeValue;
				// $methodTag=$objDOM->getElementsByTagName("method");
				// echo "method=".$method=$methodTag->item(0)->nodeValue;
				// $cancelTag=$objDOM->getElementsByTagName("cancel")->item(0);
				// echo "<br>cancel=".$cancel = $cancelTag->getAttribute("status");
			}
			else if($attribNode=="fail")
			{
				$error=$objDOM->getElementsByTagName("error")->item(0);
    			$values['error_code'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("code");
    			$values['error_msg'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("msg");	
			}
			
			$this->object =$values;
	 	}//end if	
   }//end function
	
}
?>