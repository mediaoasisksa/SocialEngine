<?php
class ScheduleClass
{
	var $object;
	
	function ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $values, $classRoom)
	{
		require_once("AuthBase.php");
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$method = "create";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		#for teacher account pass parameter 'presenter_email'
                //This is the unique email of the presenter that will identify the presenter in WizIQ. Make sure to add
                //this presenter email to your organization�s teacher account. � For more information visit at: (http://developer.wiziq.com/faqs)
		//$requestParameters["presenter_email"]="mediaoasistech@gmail.com";
		#for room based account pass parameters 'presenter_id', 'presenter_name'
		$requestParameters["presenter_id"] = $values['user_id'];
		$requestParameters["presenter_name"] = $values['name'];
		$requestParameters["start_time"] = $values['starttime'];
		$requestParameters["title"]=$values['title']; //Required
		$requestParameters["duration"]=$values['duration']; //optional
		$requestParameters["time_zone"]= "Asia/Riyadh"; //$values['timezone']; //optional
		$requestParameters["attendee_limit"]=$values['attendee_limit'];//optional
		$requestParameters["control_category_id"]=""; //$values['control_category_id']; //optional
		$requestParameters["create_recording"]=$values['create_recording'] ? "true" : "false"; //optional
		$requestParameters["return_url"]=""; //optional
		$requestParameters["status_ping_url"]= "https://www.consul2.com" . $classRoom->getHref(); //optional
        $requestParameters["language_culture_name"]=$values['language'];
        // print_r($requestParameters);die;
		$httpRequest=new HttpRequest();
		try
		{
			$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=create',http_build_query($requestParameters, '', '&')); 
		}
		catch(Exception $e)
		{	
	  		//echo $e->getMessage();
	  		$values['error_code'] = true;
			$values['error_msg'] =$e->getMessage();
			$this->object = $values;
		}
	
 		if(!empty($XMLReturn))
 		{
 			try
			{
			  $objDOM = new DOMDocument();
			  $objDOM->loadXML($XMLReturn);
	  
			}
			catch(Exception $e)
			{
			  	$values['error_code'] = true;
			$values['error_msg'] =$e->getMessage();
			}
		$status=$objDOM->getElementsByTagName("rsp")->item(0);
    	$attribNode = $status->getAttribute("status");
    	
		if($attribNode=="ok")
		{
			$values['class_id'] = $objDOM->getElementsByTagName("class_id")->item(0)->nodeValue;
			$values['class_master_id'] = $objDOM->getElementsByTagName("class_master_id")->item(0)->nodeValue;
			$values['recording_url'] = $objDOM->getElementsByTagName("recording_url")->item(0)->nodeValue;
			$values['presenter_email'] = $objDOM->getElementsByTagName("presenter_email")->item(0)->nodeValue;
			$values['presenter_url'] = $objDOM->getElementsByTagName("presenter_url")->item(0)->nodeValue;
		}
		else if($attribNode=="fail")
		{
			$error=$objDOM->getElementsByTagName("error")->item(0);
			$values['error_code'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("code");
			$values['error_msg'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("msg");
		}
		
		//print_r($values);die;
		$this->object =$values;
	 }//end if	
	 
	
   }//end function
	
}
?>