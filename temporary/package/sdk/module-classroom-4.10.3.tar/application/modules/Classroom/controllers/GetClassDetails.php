<?php

class GetClassDetails
{
	var $object;
	function GetClassDetails($secretAcessKey,$access_key,$webServiceUrl, $master_id)
	{
	    
		require_once("AuthBase.php");
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$method = "view_schedule";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		$requestParameters["class_master_id"] = $master_id;

		$httpRequest=new HttpRequest();
		
		try
		{
			$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=view_schedule',http_build_query($requestParameters, '', '&')); 
		}
		catch(Exception $e)
		{	
	  	$values['error_msg'] = true; 
	  	$this->object =$values;
	  	return;
		}
	
 		if(!empty($XMLReturn))
 		{
 			try
			{
			  $objDOM = new DOMDocument();
			  $objDOM->loadXML($XMLReturn);
	  
			}
			catch(Exception $e)
			{
			  $values['error_msg'] = true; 
			  $this->object =$values;
			  return;
			}
			$status=$objDOM->getElementsByTagName("rsp")->item(0);
			
			if(!$status) {
			   $values['error_msg'] = true; 
			   $this->object =$values;
			   return;
			}
    		$attribNode = $status->getAttribute("status");
    		
    		$values = array();
			if($attribNode=="ok")
			{
			    
                $values['class_title'] = $objDOM->getElementsByTagName("class_title")->item(0)->nodeValue;
                $values['class_id'] = $objDOM->getElementsByTagName("class_id")->item(0)->nodeValue;
                $values['recording_url'] = $objDOM->getElementsByTagName("recording_url")->item(0)->nodeValue;
                $values['start_time'] = $objDOM->getElementsByTagName("start_time")->item(0)->nodeValue;
                $values['duration'] = $objDOM->getElementsByTagName("duration")->item(0)->nodeValue;
                $values['class_status'] = $objDOM->getElementsByTagName("class_status")->item(0)->nodeValue;
                $values['class_recording_status'] = $objDOM->getElementsByTagName("class_recording_status")->item(0)->nodeValue;
                $values['attendance_report_status'] = $objDOM->getElementsByTagName("attendance_report_status")->item(0)->nodeValue;
                $values['presenter_url'] = $objDOM->getElementsByTagName("presenter_url")->item(0)->nodeValue;

			 //   <recurring_list><class_details perma_class="false"><class_title>My First Live Class</class_title><class_id>1415608</class_id><recording_url></recording_url><start_time>3/11/2020 6:00:00 AM</start_time><duration>134</duration><class_status>upcoming</class_status><class_recording_status>recording not opted</class_recording_status><attendance_report_status>not_available</attendance_report_status><presenter_list><presenter> <presenter_email></presenter_email><presenter_url><!--[CDATA[https://backend.wiziqxt.com/landing/session/v1/dfdef2ae05959339e08ce8097b701e18fda1c6997d5651e2e3425ee792351dd0/p?hash=MTQxNTYwODpkYjAyZTc3YjZmNGI0NTE5NmM4MzI4N2I2NTNhNjFkZTlmNGY2YWFjNjc0NGIwNjQ=]]--></presenter_url></presenter></presenter_list></class_details></recurring_list>
			    
				// $methodTag=$objDOM->getElementsByTagName("method");
				// echo "method=".$method=$methodTag->item(0)->nodeValue;
				// $modifyTag=$objDOM->getElementsByTagName("modify")->item(0);
				// echo "<br>modify=".$modify = $modifyTag->getAttribute("status");
			}
			else if($attribNode=="fail")
			{
						$error=$objDOM->getElementsByTagName("error")->item(0);
			$values['error_code'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("code");
			$values['error_msg'] = $objDOM->getElementsByTagName("error")->item(0)->getAttribute("msg");
			}
			
			$this->object =$values;
	 	}//end if	
   }//end function
	
}
?>