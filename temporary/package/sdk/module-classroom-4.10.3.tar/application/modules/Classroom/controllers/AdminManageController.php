<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: AdminManageController.php 9747 2012-07-26 02:08:08Z john $
 * @author     Jung
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_AdminManageController extends Core_Controller_Action_Admin
{

  public function indexAction()
  {
    $this->view->navigation = $navigation = Engine_Api::_()->getApi('menus', 'core')
      ->getNavigation('classroom_admin_main', array(), 'classroom_admin_main_manage');

    if ($this->getRequest()->isPost())
    {
      $values = $this->getRequest()->getPost();
      foreach ($values as $key=>$value) {
        if ($key == 'delete_' . $value)
        {
          $classroom = Engine_Api::_()->getItem('classroom', $value);
          $classroom->delete();
        }
      }
    }
    
    $page = $this->_getParam('page',1);
    $this->view->paginator = Engine_Api::_()->getItemTable('classroom')->getClassroomPaginator(array(
      'orderby' => 'admin_id',
      'admin' => true
    ));
    $this->view->paginator->setItemCountPerPage(25);
    $this->view->paginator->setCurrentPageNumber($page);
  }

  public function deleteAction()
  {
    // In smoothbox
    $this->_helper->layout->setLayout('admin-simple');
    $id = $this->_getParam('topic_id');
    $this->view->classroom_id = $id;
    
    // Check post
    if( $this->getRequest()->isPost())
    {
      $db = Engine_Db_Table::getDefaultAdapter();
      $db->beginTransaction();

      try
      {
        $classroom = Engine_Api::_()->getItem('classroom', $id);
        $classroom->delete();
        $db->commit();
      }

      catch( Exception $e )
      {
        $db->rollBack();
        throw $e;
      }

      $this->_forward('success', 'utility', 'core', array(
          'smoothboxClose' => 10,
          'parentRefresh'=> 10,
          'messages' => array('')
      ));
    }
    // Output
    $this->renderScript('admin-manage/delete.tpl');
  }
  
   //ACTION FOR ENABLE/DISABLE ALL PRODUCTS OF STORE THE SITESTORE
  public function toggleOfficeStatusAction() {
    
     //USER VALIDATION
    if (!$this->_helper->requireUser()->isValid())
      return;

    $this->_helper->layout->setLayout('admin-simple');
    $store_id = $this->_getParam('id');
    $approved = $this->_getParam('approved');
    
      if($approved) {
          $classroom = Engine_Api::_()->getItem('classroom', $store_id);
          $classroom->approved = 0;
          $classroom->save();
      } else {
          $classroom = Engine_Api::_()->getItem('classroom', $store_id);
          $classroom->approved = 1;
          $classroom->save();
      }

      $this->_redirectCustom(Zend_Controller_Front::getInstance()->getRouter()->assemble(array('module' => 'classroom', 'controller' => 'manage'), 'admin_default', true));
      $this->_forward('success', 'utility', 'core', array(
              'smoothboxClose' => true,
//              'parentRefresh' => 10,
               'parentRedirect' => Zend_Controller_Front::getInstance()->getRouter()->assemble(array('module' => 'classroom', 'controller' => 'manage'), 'admin_default', true),
//              'messages' => array(Zend_Registry::get('Zend_Translate')->_(''))
      ));
    
    
  }
  
}