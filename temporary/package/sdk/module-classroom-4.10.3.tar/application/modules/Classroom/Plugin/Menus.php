<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Menus.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Classroom_Plugin_Menus
{
  public function canCreateClassrooms()
  {
    // Must be logged in
    $viewer = Engine_Api::_()->user()->getViewer();
    if( !$viewer || !$viewer->getIdentity() ) {
      return false;
    }

    // Must be able to create events
    if( !Engine_Api::_()->authorization()->isAllowed('classroom', $viewer, 'create') ) {
      return false;
    }

    return true;
  }

  public function canViewClassrooms()
  {
    $viewer = Engine_Api::_()->user()->getViewer();

    // Must be able to view events
    if( !Engine_Api::_()->authorization()->isAllowed('classroom', $viewer, 'view') ) {
      return false;
    }

    return true;
  }

  public function onMenuInitialize_ClassroomMainManage()
  {
    $viewer = Engine_Api::_()->user()->getViewer();

    if( !$viewer->getIdentity() )
    {
      return false;
    }
    return true;
  }

  public function onMenuInitialize_ClassroomMainCreate()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    
    if( !$viewer->getIdentity() )
    {
      return false;
    }

    if( !Engine_Api::_()->authorization()->isAllowed('classroom', null, 'create') )
    {
      return false;
    }

    return true;
  }
  
  public function onMenuInitialize_ClassroomProfileEdit()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();
    if( $subject->getType() !== 'classroom' )
    {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }

    if( !$viewer->getIdentity() || !$subject->authorization()->isAllowed($viewer, 'edit') )
    {
      return false;
    }

    if( !$subject->authorization()->isAllowed($viewer, 'edit') )
    {
      return false;
    }
    
    return array(
      'label' => 'Edit Classroom Details',
      'class' => 'icon_classroom_edit',
      'route' => 'classroom_specific',
      'params' => array(
        'controller' => 'classroom',
        'action' => 'edit',
        'classroom_id' => $subject->getIdentity(),
        'ref' => 'profile'
      )
    );
  }

  public function onMenuInitialize_ClassroomProfileStyle()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();
    if( $subject->getType() !== 'classroom' )
    {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }

    if( !$viewer->getIdentity() || !$subject->authorization()->isAllowed($viewer, 'edit') )
    {
      return false;
    }

    if( !$subject->authorization()->isAllowed($viewer, 'style') )
    {
      return false;
    }

    return array(
      'label' => 'Edit Classroom Style',
      'class' => 'smoothbox icon_style',
      'route' => 'classroom_specific',
      'params' => array(
        'action' => 'style',
        'classroom_id' => $subject->getIdentity(),
        'format' => 'smoothbox',
      )
    );
  }

  public function onMenuInitialize_ClassroomProfileMember()
  {
    $menu = array();
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();
    if( $subject->getType() !== 'classroom' )
    {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }

    if( !$viewer->getIdentity() )
    {
      return false;
    }

    $row = $subject->membership()->getRow($viewer);

    // Not yet associated at all
    if( null === $row )
    {
      if( $subject->membership()->isResourceApprovalRequired() ) {
        $menu[] =  array(
          'label' => 'Request Membership',
          'class' => 'smoothbox icon_classroom_join',
          'route' => 'classroom_extended',
          'params' => array(
            'controller' => 'member',
            'action' => 'request',
            'classroom_id' => $subject->getIdentity(),
          ),
        );
      } else {
        $menu[] =  array(
          'label' => 'Join Classroom',
          'class' => 'smoothbox icon_classroom_join',
          'route' => 'classroom_extended',
          'params' => array(
            'controller' => 'member',
            'action' => 'join',
            'classroom_id' => $subject->getIdentity()
          ),
        );
      }
    }

    // Full member
    // @todo consider owner
    else if( $row->active )
    {
      if( !$subject->isOwner($viewer) ) {
        $menu[] =  array(
          'label' => 'Leave Classroom',
          'class' => 'smoothbox icon_classroom_leave',
          'route' => 'classroom_extended',
          'params' => array(
            'controller' => 'member',
            'action' => 'leave',
            'classroom_id' => $subject->getIdentity()
          ),
        );
      }
    }

    else if( !$row->resource_approved && $row->user_approved )
    {
      $menu[] =  array(
        'label' => 'Cancel Membership Request',
        'class' => 'smoothbox icon_classroom_cancel',
        'route' => 'classroom_extended',
        'params' => array(
          'controller' => 'member',
          'action' => 'cancel',
          'classroom_id' => $subject->getIdentity()
        ),
      );
    }

    else if( !$row->user_approved && $row->resource_approved )
    {
      $menu[] = array(
          'label' => 'Accept Membership Request',
          'class' => 'smoothbox icon_classroom_accept',
          'route' => 'classroom_extended',
          'params' => array(
            'controller' => 'member',
            'action' => 'accept',
            'classroom_id' => $subject->getIdentity()
          ),
      );

      $menu[] =  array(
          'label' => 'Ignore Membership Request',
          'class' => 'smoothbox icon_classroom_reject',
          'route' => 'classroom_extended',
          'params' => array(
            'controller' => 'member',
            'action' => 'reject',
            'classroom_id' => $subject->getIdentity()
          ),
      );
    }

    else
    {
      throw new Classroom_Model_Exception('Wow, something really strange happened.');
    }

    $canDelete = Engine_Api::_()->authorization()->isAllowed($subject, null, 'delete');
    if( $canDelete ) {
      $menu[] = array(
        'label' => 'Delete Classroom',
        'class' => 'smoothbox icon_classroom_delete',
        'route' => 'classroom_specific',
        'params' => array(
          'action' => 'delete',
          'classroom_id' => $subject->getIdentity()
        ),
      );
    }

    if( count($menu) == 1 ) {
      return $menu[0];
    }
    return $menu;
  }

  public function onMenuInitialize_ClassroomProfileReport()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();
    if( $subject->getType() !== 'classroom' )
    {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }
    
    if( !$viewer->getIdentity() ||
        $subject->isOwner($viewer) ) {
      return false;
    } else {
      return array(
        'label' => 'Report',
        'class' => 'smoothbox icon_report',
        'route' => 'default',
        'params' => array(
          'module' => 'core',
          'controller' => 'report',
          'action' => 'create',
          'subject' => $subject->getGuid(),
          'format' => 'smoothbox',
        ),
      );
    }
  }

  public function onMenuInitialize_ClassroomProfileInvite()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();

    if( $subject->getType() !== 'classroom' ) {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }

    if( !$subject->authorization()->isAllowed($viewer, 'invite') ) {
      return false;
    }

    return array(
      'label' => 'Invite Members',
      'class' => 'smoothbox icon_invite',
      'route' => 'classroom_extended',
      'params' => array(
        //'module' => 'classroom',
        'controller' => 'member',
        'action' => 'invite',
        'classroom_id' => $subject->getIdentity(),
        'format' => 'smoothbox',
      ),
    );
  }

  public function onMenuInitialize_ClassroomProfileShare()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();
    if( $subject->getType() !== 'classroom' )
    {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }

    if( !$viewer->getIdentity() )
    {
      return false;
    }
    
    return array(
      'label' => 'Share Classroom',
      'class' => 'smoothbox icon_share',
      'route' => 'default',
      'params' => array(
        'module' => 'activity',
        'controller' => 'index',
        'action' => 'share',
        'type' => $subject->getType(),
        'id' => $subject->getIdentity(),
        'format' => 'smoothbox',
      ),
    );
  }

  public function onMenuInitialize_ClassroomProfileMessage()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    $subject = Engine_Api::_()->core()->getSubject();
    if( $subject->getType() !== 'classroom' ) {
      throw new Classroom_Model_Exception('Whoops, not a classroom!');
    }

    if( !$viewer->getIdentity() || !$subject->isOwner($viewer) ) {
      return false;
    }

    return array(
      'label' => 'Message Members',
      'class' => 'icon_message',
      'route' => 'messages_general',
      'params' => array(
        'action' => 'compose',
        'to' => $subject->getIdentity(),
        'multi' => 'classroom'
      )
    );
  }
}
