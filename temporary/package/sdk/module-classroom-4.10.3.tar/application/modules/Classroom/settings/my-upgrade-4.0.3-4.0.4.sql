
/* This query was removed for changes in 4.1.0 */
/*
INSERT IGNORE INTO `engine4_core_tasks` (`title`, `category`, `module`, `plugin`, `timeout`, `type`) VALUES
('Rebuild Classroom Privacy', 'rebuild_privacy', 'classroom', 'Classroom_Plugin_Task_Maintenance_RebuildPrivacy', 0, 'semi-automatic');
*/

REPLACE INTO `engine4_core_mailtemplates` (`type`, `module`, `vars`) VALUES
('notify_classroom_accepted', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_approve', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_discussion_reply', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_discussion_response', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_invite', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_promote', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]');

UPDATE `engine4_authorization_permissions`
SET `value` = '["registered", "member","officer", "owner"]'
WHERE `value` = '["registered", member","officer", "owner"]' ;

UPDATE `engine4_core_pages` SET custom = 0 WHERE `name` = 'classroom_profile_index' LIMIT 1;

INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`) VALUES
('classroom_main', 'standard', 'Classroom Main Navigation Menu'),
('classroom_profile', 'standard', 'Classroom Profile Options Menu')
;

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('authorization_admin_level_classroom', 'classroom', 'Classrooms', '', '{"route":"admin_default","module":"classroom","controller":"settings","action":"level"}', 'authorization_admin_level', '', 999)
;
