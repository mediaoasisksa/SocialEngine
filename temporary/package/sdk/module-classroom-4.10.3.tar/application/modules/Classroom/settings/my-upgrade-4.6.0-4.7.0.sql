UPDATE `engine4_activity_notificationtypes` SET `body` = 'Your request to join the classroom {item:$object} has been approved.' WHERE `type` = 'classroom_accepted';
