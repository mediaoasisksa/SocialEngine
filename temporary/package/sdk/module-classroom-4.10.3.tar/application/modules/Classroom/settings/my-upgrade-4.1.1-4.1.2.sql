
UPDATE `engine4_core_pages`
SET `provides` = 'subject=classroom'
WHERE `name` = 'classroom_profile_index' ;
