<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: content.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */
return array(
  array(
    'title' => 'Profile Classrooms',
    'description' => 'Displays a member\'s classrooms on their profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-classrooms',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Classrooms',
      'titleCount' => true,
    ),
    'requirements' => array(
      'subject' => 'user',
    ),
  ),
    array(
    'title' => 'Profile Live Classes',
    'description' => 'Displays a member\'s live classes on their profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-live-classes',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Live Classes',
      'titleCount' => true,
    ),
    'requirements' => array(
      'subject' => 'user',
    ),
  ),
  array(
    'title' => 'Classroom Profile Discussions',
    'description' => 'Displays a classroom\'s discussions on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-discussions',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Discussions',
      'titleCount' => true,
    ),
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Classroom Cover Photo',
    'description' => 'Displays a classroom\'s cover photo on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.cover-photo',
    'requirements' => array(
      'viewer',
    ),
  ),
  array(
    'title' => 'Classroom Profile Info',
    'description' => 'Displays a classroom\'s info (creation date, member count, leader, officers, etc) on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-info',
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Classroom Profile Members',
    'description' => 'Displays a classroom\'s members on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-members',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Members',
      'titleCount' => true,
    ),
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Classroom Profile Options',
    'description' => 'Displays a menu of actions (edit, report, join, invite, etc) that can be performed on a classroom on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-options',
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Classroom Profile Photo',
    'description' => 'Displays a classroom\'s photo on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-photo',
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Classroom Profile Photos',
    'description' => 'Displays a classroom\'s photos on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-photos',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Photos',
      'titleCount' => true,
    ),
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Classroom Profile Status',
    'description' => 'Displays a classroom\'s title on its profile.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-status',
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title'=> 'Classroom Profile Events',
    'description' => 'Displays a classroom\'s events on its profile',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.profile-events',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Events',
      'titleCount' => true,
    ),
    'requirements' => array(
      'subject' => 'classroom',
    ),
  ),
  array(
    'title' => 'Popular Classrooms',
    'description' => 'Displays a list of most viewed classrooms.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.list-popular-classrooms',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Popular Classrooms',
    ),
    'requirements' => array(
      'no-subject',
    ),
    'adminForm' => array(
      'elements' => array(
        array(
          'Radio',
          'popularType',
          array(
            'label' => 'Popular Type',
            'multiOptions' => array(
              'view' => 'Views',
              'member' => 'Members',
            ),
            'value' => 'view',
          )
        ),
      )
    ),
  ),
  array(
    'title' => 'Recent Classrooms',
    'description' => 'Displays a list of recently created classrooms.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.list-recent-classrooms',
    'isPaginated' => true,
    'defaultParams' => array(
      'title' => 'Recent Classrooms',
    ),
    'requirements' => array(
      'no-subject',
    ),
    'adminForm' => array(
      'elements' => array(
        array(
          'Radio',
          'recentType',
          array(
            'label' => 'Recent Type',
            'multiOptions' => array(
              'creation' => 'Creation Date',
              'modified' => 'Modified Date',
            ),
            'value' => 'creation',
          )
        ),
      )
    ),
  ),
  
  array(
    'title' => 'Classroom Browse Search',
    'description' => 'Displays a search form in the classroom browse page.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.browse-search',
    'requirements' => array(
      'no-subject',
    ),
  ),
  array(
    'title' => 'Classroom Browse Menu',
    'description' => 'Displays a menu in the classroom browse page.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.browse-menu',
    'requirements' => array(
      'no-subject',
    ),
  ),
  array(
    'title' => 'Classroom Browse Quick Menu',
    'description' => 'Displays a small menu in the classroom browse page.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.browse-menu-quick',
    'requirements' => array(
      'no-subject',
    ),
  ),
  array(
    'title' => 'Classroom Categories',
    'description' => 'Display a list of categories for classrooms.',
    'category' => 'Classrooms',
    'type' => 'widget',
    'name' => 'classroom.list-categories',
  ),
) ?>