
ALTER TABLE `engine4_classroom_classrooms`
  CHANGE COLUMN `description` `description` text NOT NULL ;
