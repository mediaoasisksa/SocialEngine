
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @author		 John
 */


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_albums`
--

DROP TABLE IF EXISTS `engine4_classroom_albums` ;
CREATE TABLE `engine4_classroom_albums` (
  `album_id` int(11) unsigned NOT NULL auto_increment,
  `classroom_id` int(11) unsigned NOT NULL,

  `title` varchar(128) NOT NULL,
  `description` varchar(255) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `search` tinyint(1) NOT NULL default '1',
  `coverphotoparams` VARCHAR ( 265 ) NULL,
  `type` VARCHAR ( 265 ) NULL,
  `photo_id` int(11) unsigned NOT NULL default '0',
  `view_count` int(11) unsigned NOT NULL default '0',
  `comment_count` int(11) unsigned NOT NULL default '0',
  `like_count` int(11) unsigned NOT NULL default '0',
  `collectible_count` int(11) unsigned NOT NULL default '0',
   PRIMARY KEY (`album_id`),
   KEY `classroom_id` (`classroom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_categories`
--

DROP TABLE IF EXISTS `engine4_classroom_categories` ;
CREATE TABLE IF NOT EXISTS `engine4_classroom_categories` (
  `category_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(64) NOT NULL,
  PRIMARY KEY  (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;

--
-- Dumping data for table `engine4_classroom_categories`
--

INSERT IGNORE INTO `engine4_classroom_categories` (`title`) VALUES
('Animals'),
('Business & Finance'),
('Computers & Internet'),
('Cultures & Community'),
('Dating & Relationships'),
('Entertainment & Arts'),
('Family & Home'),
('Games'),
('Government & Politics'),
('Health & Wellness'),
('Hobbies & Crafts'),
('Music'),
('Recreation & Sports'),
('Regional'),
('Religion & Beliefs'),
('Schools & Education'),
('Science')
;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_listitems`
--

DROP TABLE IF EXISTS `engine4_classroom_listitems`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_listitems` (
  `listitem_id` int(11) unsigned NOT NULL auto_increment,
  `list_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`listitem_id`),
  KEY `list_id` (`list_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_lists`
--

DROP TABLE IF EXISTS `engine4_classroom_lists`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_lists` (
  `list_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(64) NOT NULL default '',
  `owner_id` int(11) unsigned NOT NULL,
  `child_count` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`list_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_classrooms`
--

DROP TABLE IF EXISTS `engine4_classroom_classrooms`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_classrooms` (
  `classroom_id` int(11) unsigned NOT NULL auto_increment,
  `user_id` int(11) unsigned NOT NULL,
  
  `title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) unsigned NOT NULL default '0',
  `search` tinyint(1) NOT NULL default '1',
  `invite` tinyint(1) NOT NULL default '1',
  `approval` tinyint(1) NOT NULL default '0',
  `photo_id` int(11) unsigned NOT NULL default '0',
  `coverphoto` INT ( 11 ) NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `member_count` smallint(6) unsigned NOT NULL,
  `view_count` int(11) unsigned NOT NULL default '0',
  `comment_count` int(11) unsigned NOT NULL default '0',
  `like_count` int(11) unsigned NOT NULL default '0',
  `view_privacy` VARCHAR(24) NOT NULL default 'everyone',
  PRIMARY KEY  (`classroom_id`),
  KEY `user_id` (`user_id`),
  KEY `search` (`search`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_membership`
--

DROP TABLE IF EXISTS `engine4_classroom_membership`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL default '0',
  `resource_approved` tinyint(1) NOT NULL default '0',
  `user_approved` tinyint(1) NOT NULL default '0',
  `message` text NULL,
  `title` text NULL,
  PRIMARY KEY  (`resource_id`, `user_id`),
  KEY `REVERSE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_photos`
--

DROP TABLE IF EXISTS `engine4_classroom_photos`;
CREATE TABLE `engine4_classroom_photos` (
  `photo_id` int(11) unsigned NOT NULL auto_increment,
  `album_id` int(11) unsigned NOT NULL,
  `classroom_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,

  `title` varchar(128) NOT NULL,
  `description` varchar(255) NOT NULL,
  `collection_id` int(11) unsigned NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL default '0',
  `comment_count` int(11) unsigned NOT NULL default '0',
  `like_count` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY (`photo_id`),
  KEY `album_id` (`album_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_posts`
--

DROP TABLE IF EXISTS `engine4_classroom_posts`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_posts` (
  `post_id` int(11) unsigned NOT NULL auto_increment,
  `topic_id` int(11) unsigned NOT NULL,
  `classroom_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  
  `body` text NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY  (`post_id`),
  KEY `topic_id` (`topic_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_topics`
--

DROP TABLE IF EXISTS `engine4_classroom_topics`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_topics` (
  `topic_id` int(11) unsigned NOT NULL auto_increment,
  `classroom_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  
  `title` varchar(64) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `sticky` tinyint(1) NOT NULL default '0',
  `closed` tinyint(1) NOT NULL default '0',
  `post_count` int(11) unsigned NOT NULL default '0',
  `view_count` int(11) unsigned NOT NULL default '0',
  `lastpost_id` int(11) unsigned NOT NULL default '0',
  `lastposter_id` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`topic_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Table structure for table `engine4_classroom_topicwatches`
--

DROP TABLE IF EXISTS `engine4_classroom_topicwatches`;
CREATE TABLE IF NOT EXISTS `engine4_classroom_topicwatches` (
  `resource_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `watch` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`resource_id`,`topic_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci ;


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_core_jobtypes`
--

INSERT IGNORE INTO `engine4_core_jobtypes` (`title`, `type`, `module`, `plugin`, `priority`) VALUES
('Rebuild Classroom Privacy', 'classroom_maintenance_rebuild_privacy', 'classroom', 'Classroom_Plugin_Job_Maintenance_RebuildPrivacy', 50);


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_core_mailtemplates`
--

INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, `vars`) VALUES
('notify_classroom_accepted', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_approve', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_discussion_reply', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_discussion_response', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_invite', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),
('notify_classroom_promote', 'classroom', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]');


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_core_menus`
--

INSERT IGNORE INTO `engine4_core_menus` (`name`, `type`, `title`) VALUES
('classroom_main', 'standard', 'Classroom Main Navigation Menu'),
('classroom_profile', 'standard', 'Classroom Profile Options Menu')
;


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_core_menuitems`
--

INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('core_main_classroom', 'classroom', 'Classrooms', '', '{"route":"classroom_general","icon":"fa-classroom"}', 'core_main', '', 6),

('core_sitemap_classroom', 'classroom', 'Classrooms', '', '{"route":"classroom_general"}', 'core_sitemap', '', 6),

('classroom_main_browse', 'classroom', 'Browse Classrooms', '', '{"route":"classroom_general","action":"browse"}', 'classroom_main', '', 1),
('classroom_main_manage', 'classroom', 'My Classrooms', 'Classroom_Plugin_Menus', '{"route":"classroom_general","action":"manage"}', 'classroom_main', '', 2),
('classroom_main_create', 'classroom', 'Create New Classroom', 'Classroom_Plugin_Menus', '{"route":"classroom_general","action":"create"}', 'classroom_main', '', 3),

('classroom_quick_create', 'classroom', 'Create New Classroom', 'Classroom_Plugin_Menus::canCreateClassrooms', '{"route":"classroom_general","action":"create","class":"buttonlink icon_classroom_new"}', 'classroom_quick', '', 1),

('classroom_profile_edit', 'classroom', 'Edit Profile', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 1),
('classroom_profile_style', 'classroom', 'Edit Styles', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 2),

('classroom_profile_member', 'classroom', 'Member', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 3),
('classroom_profile_report', 'classroom', 'Report Classroom', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 4),
('classroom_profile_share', 'classroom', 'Share', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 5),
('classroom_profile_invite', 'classroom', 'Invite', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 6),
('classroom_profile_message', 'classroom', 'Message Members', 'Classroom_Plugin_Menus', '', 'classroom_profile', '', 7),

('core_admin_main_plugins_classroom', 'classroom', 'Classrooms', '', '{"route":"admin_default","module":"classroom","controller":"manage"}', 'core_admin_main_plugins', '', 999),

('classroom_admin_main_manage', 'classroom', 'Manage Classrooms', '', '{"route":"admin_default","module":"classroom","controller":"manage"}', 'classroom_admin_main', '', 1),
('classroom_admin_main_settings', 'classroom', 'Global Settings', '', '{"route":"admin_default","module":"classroom","controller":"settings"}', 'classroom_admin_main', '', 2),
('classroom_admin_main_level', 'classroom', 'Member Level Settings', '', '{"route":"admin_default","module":"classroom","controller":"settings","action":"level"}', 'classroom_admin_main', '', 3),
('classroom_admin_main_categories', 'classroom', 'Categories', '', '{"route":"admin_default","module":"classroom","controller":"settings","action":"categories"}', 'classroom_admin_main', '', 4),

('authorization_admin_level_classroom', 'classroom', 'Classrooms', '', '{"route":"admin_default","module":"classroom","controller":"settings","action":"level"}', 'authorization_admin_level', '', 999),
('mobi_browse_classroom', 'classroom', 'Classrooms', '', '{"route":"classroom_general"}', 'mobi_browse', '', 8);


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_core_modules`
--

INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES
('classroom', 'Classrooms', 'Classrooms', '4.8.12', 1, 'extra');


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_core_settings`
--

INSERT IGNORE INTO `engine4_core_settings` VALUES 
('classroom.html', 1),
('classroom.bbcode', 1);


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_activity_actiontypes`
--

INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `editable`, `is_generated`) VALUES
('classroom_create', 'classroom', '{item:$subject} created a new classroom:', 1, 5, 1, 1, 1, 0, 1),
('classroom_join', 'classroom', '{item:$subject} joined the classroom {item:$object}', 1, 3, 1, 1, 1, 0, 1),
('classroom_promote', 'classroom', '{item:$subject} has been made an officer for the classroom {item:$object}', 1, 3, 1, 1, 1, 0, 1),
('classroom_topic_create', 'classroom', '{item:$subject} posted a {itemChild:$object:topic:$child_id} in the classroom {item:$object}: {body:$body}', 1, 3, 1, 1, 1, 0, 1),
('classroom_topic_reply', 'classroom', '{item:$subject} replied to a {itemChild:$object:topic:$child_id} in the classroom {item:$object}: {body:$body}', 1, 3, 1, 1, 1, 0, 1),
('classroom_photo_upload', 'classroom', '{item:$subject} added {var:$count} photo(s).', 1, 3, 2, 1, 1, 0, 1),
('post_classroom', 'classroom', '{actors:$subject:$object}: {body:$body}', 1, 7, 1, 4, 1, 1, 0),
('classroom_cover_photo_update', 'classroom', '{item:$subject} has updated {item:$object} cover photo.', 1, 5, 1, 4, 1, 0, 1)
;

-- --------------------------------------------------------

--
-- Dumping data for table `engine4_activity_notificationtypes`
--

INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`) VALUES
('classroom_discussion_response', 'classroom', '{item:$subject} has {item:$object:posted} on a {itemParent:$object::classroom topic} you created.', 0, ''),
('classroom_discussion_reply', 'classroom', '{item:$subject} has {item:$object:posted} on a {itemParent:$object::classroom topic} you posted on.', 0, ''),
('classroom_invite', 'classroom', '{item:$subject} has invited you to the classroom {item:$object}.', 1, 'classroom.widget.request-classroom'),
('classroom_approve', 'classroom', '{item:$subject} has requested to join the classroom {item:$object}.', 0, ''),
('classroom_accepted', 'classroom', 'Your request to join the classroom {item:$object} has been approved.', 0, ''),
('classroom_promote', 'classroom', 'You were promoted to officer in the classroom {item:$object}.', 0, '')
;


-- --------------------------------------------------------

--
-- Dumping data for table `engine4_authorization_permissions`
--

-- ALL
-- auth_view, auth_comment, auth_photo
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'auth_view' as `name`,
    5 as `value`,
    '["everyone", "registered", "member"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'auth_comment' as `name`,
    5 as `value`,
    '["registered", "member", "officer"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'auth_photo' as `name`,
    5 as `value`,
    '["registered", "member", "officer"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'auth_event' as `name`,
    5 as `value`,
    '["registered", "member", "officer"]' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');

-- ADMIN, MODERATOR
-- create, delete, edit, view, comment, photo, style, invite
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'create' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'delete' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'edit' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'view' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'comment' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'photo.edit' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'topic.edit' as `name`,
    2 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'photo' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'event' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'style' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'invite' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('moderator', 'admin');

-- USER
-- create, delete, edit, invite, view, comment, photo, style, invite, photo.edit, topic.edit
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'create' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'delete' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'edit' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'comment' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'photo' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'event' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'style' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'invite' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'photo.edit' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'topic.edit' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('user');

-- PUBLIC
-- view
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'view' as `name`,
    1 as `value`,
    NULL as `params`
  FROM `engine4_authorization_levels` WHERE `type` IN('public');

-- ALL
-- commentHtml
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'commentHtml' as `name`,
    3 as `value`,
    'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr, iframe' as `params`
  FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');

-- coverphotoupload
INSERT IGNORE INTO `engine4_authorization_permissions`
  SELECT
    level_id as `level_id`,
    'classroom' as `type`,
    'coverphotoupload' as `name`,
    1 as `value`,
    NULL as `params`
FROM `engine4_authorization_levels` WHERE `type` NOT IN('public');
