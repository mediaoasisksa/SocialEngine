<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Classroom
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @author     John
 */
return array(
  // Package -------------------------------------------------------------------
  'package' => array(
    'type' => 'module',
    'name' => 'classroom',
    'version' => '4.10.3',
    'revision' => '$Revision: 10271 $',
    'path' => 'application/modules/Classroom',
    'repository' => 'socialengine.com',
    'title' => 'Classrooms',
    'description' => 'Classrooms',
    'author' => 'Webligo Developments',
    'dependencies' => array(
      array(
        'type' => 'module',
        'name' => 'core',
        'minVersion' => '4.2.0',
      ),
    ),
    'actions' => array(
       'install',
       'upgrade',
       'refresh',
       'enable',
       'disable',
     ),
    'callback' => array(
      'path' => 'application/modules/Classroom/settings/install.php',
      'class' => 'Classroom_Installer',
    ),
    'directories' => array(
      'application/modules/Classroom',
    ),
    'files' => array(
      'application/languages/en/classroom.csv',
    ),
  ),
  // Hooks ---------------------------------------------------------------------
  'hooks' => array(
    array(
      'event' => 'onStatistics',
      'resource' => 'Classroom_Plugin_Core'
    ),
    array(
      'event' => 'onUserDeleteBefore',
      'resource' => 'Classroom_Plugin_Core',
    ),
    array(
      'event' => 'getActivity',
      'resource' => 'Classroom_Plugin_Core',
    ),
    array(
      'event' => 'addActivity',
      'resource' => 'Classroom_Plugin_Core',
    ),
  ),
  // Items ---------------------------------------------------------------------
  'items' => array(
    'classroom',
    'classroom_album',
    'classroom_category',
    'classroom_list',
    'classroom_list_item',
    'classroom_photo',
    'classroom_post',
    'classroom_topic',
  ),
  // Routes --------------------------------------------------------------------
  'routes' => array(
    'classroom_extended' => array(
      'route' => 'classrooms/:controller/:action/*',
      'defaults' => array(
        'module' => 'classroom',
        'controller' => 'index',
        'action' => 'index',
      ),
      'reqs' => array(
        'controller' => '\D+',
        'action' => '\D+',
      )
    ),
    'classroom_general' => array(
      'route' => 'classrooms/:action/*',
      'defaults' => array(
        'module' => 'classroom',
        'controller' => 'index',
        'action' => 'browse',
      ),
      'reqs' => array(
        'action' => '(browse|create|list|manage)',
      )
    ),
    'classroom_specific' => array(
      'route' => 'classrooms/:action/:classroom_id/*',
      'defaults' => array(
        'module' => 'classroom',
        'controller' => 'classroom',
        'action' => 'index',
      ),
      'reqs' => array(
        'action' => '(edit|delete|join|leave|cancel|accept|invite|style|live-class|live-edit-class|live-join-class|live-cancel-class|live-delete-class|share-class)',
        'classroom_id' => '\d+',
      )
    ),
    'classroom_profile' => array(
      'route' => 'classroom/:id/:slug/*',
      'defaults' => array(
        'module' => 'classroom',
        'controller' => 'profile',
        'action' => 'index',
        'slug' => '',
      ),
      'reqs' => array(
        'id' => '\d+',
      )
    ),
    'classroom_topic' => array(
      'route' => 'classroom/:controller/:action/:classroom_id/:topic_id/:slug/*',
      'defaults' => array(
        'module' => 'classroom',
        'controller' => 'index',
        'action' => 'index',
        'slug' => ''
      ),
      'reqs' => array(
        'controller' => '\D+',
        'action' => '\D+',
      )
    ),
    'classroom_coverphoto' => array(
      'route' => 'classroom/coverphoto/:action/*',
      'defaults' => array(
        'module' => 'classroom',
        'controller' => 'coverphoto',
      ),
      'reqs' => array(
          'action' => '(get-cover-photo|get-main-photo|reset-cover-photo-position|upload-cover-photo|choose-from-albums|remove-cover-photo)'
      ),
    ),
  )
) ?>
