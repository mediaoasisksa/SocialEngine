<?php

namespace BigBlueButton\Exceptions;

class RuntimeException extends BaseException
{
}
