<?php

namespace BigBlueButton\Exceptions;

class ParsingException extends BaseException
{
}
