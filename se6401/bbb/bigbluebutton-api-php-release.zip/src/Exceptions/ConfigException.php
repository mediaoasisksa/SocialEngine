<?php

namespace BigBlueButton\Exceptions;

class ConfigException extends BaseException
{
}
