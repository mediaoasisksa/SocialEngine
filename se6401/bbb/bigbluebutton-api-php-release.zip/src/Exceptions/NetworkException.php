<?php

namespace BigBlueButton\Exceptions;

class NetworkException extends BaseException
{
}
