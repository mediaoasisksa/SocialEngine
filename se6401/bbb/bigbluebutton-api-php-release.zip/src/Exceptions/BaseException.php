<?php

namespace BigBlueButton\Exceptions;

use Exception;

class BaseException extends Exception
{
}
