<?php
ini_set('display_errors', 1);
error_reporting(E_ALL); 
require_once 'vendor/autoload.php';
require_once "class-db.php";
 
//define('CLIENT_ID', 'auqwP_1RDSj7HsZynjF_Q');
//define('CLIENT_SECRET', 'uYYfVKVOKteV48VMTZApECNPPFQfkDbW');

//
// define('CLIENT_ID', 'qDvHjFLZS1iRM9jQjeCjzg');
// define('CLIENT_SECRET', 'uLSq7pLbwMNedAZK2VxPYATelxZxpb9q');


// Pradeep sir credentials
define('CLIENT_ID', 'ErwLSzf_R5yMeXwBWwAjfg');
define('CLIENT_SECRET', 'DnGJdJqKbu1Xfb4bJsZwCK7sJwpP4XKI'); 
define('JWT_API_KEY', 'w778bn4KSAKD4JYLhH8Rxg'); 
define('JWT_API_SECRET', 'ymwKAxXuA65I8Ov1vjRkTsJoV1gPfKclgpbt'); 
define('REDIRECT_URI', 'http://localhost/zoom_api/zoom-api-oauth/functions.php');


/*
JWT CRedentials - Pradeep Sharma Add in index.js of sapmlep-web-app/CDN/js/index.js
API Key:
w778bn4KSAKD4JYLhH8Rxg

API Secret:
ymwKAxXuA65I8Ov1vjRkTsJoV1gPfKclgpbt

OAuth Credentials - PHP Script 
- Generate Token
- Create Meeting




*/