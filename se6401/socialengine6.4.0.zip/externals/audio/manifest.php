<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'chootools',
    'version' => '6.4.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/audio',
    'repository' => 'socialengine.com',
    'title' => 'Audio JS',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'externals/audio',
    )
  )
) ?>
