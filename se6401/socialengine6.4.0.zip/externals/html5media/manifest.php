<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'html5media',
    'version' => '6.4.0',
    'revision' => '$Revision: 10270 $',
    'path' => 'externals/html5media',
    'repository' => 'socialengine.com',
    'title' => 'Html5 Media',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/html5media',
    )
  )
) ?>
