<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocrop',
    'version' => '6.4.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/cropper',
    'repository' => 'socialengine.com',
    'title' => 'Cropper',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/cropper',
    )
  )
) ?>
