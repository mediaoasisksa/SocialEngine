<?php
return array(
  'package' => array(
    'type' => 'external',
    'name' => 'simplelightbox',
    'version' => '6.4.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/simplelightbox',
    'repository' => 'socialengine.com',
    'title' => 'external',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'externals/simplelightbox',
    )
  )
);
