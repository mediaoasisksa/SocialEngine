<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'jscolor',
    'version' => '6.4.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/jscolor',
    'repository' => 'socialengine.com',
    'title' => 'jscolor',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'externals/jscolor',
    )
  )
) ?>
