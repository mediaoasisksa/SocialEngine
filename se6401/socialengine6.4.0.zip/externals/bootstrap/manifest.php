<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'firebug',
    'version' => '6.4.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/bootstrap',
    'repository' => 'socialengine.com',
    'title' => 'Bootstrap JS',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'externals/bootstrap',
    )
  )
) ?>
