<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'desktop-notify',
    'version' => '6.4.0',
    'revision' => '$Revision: 10105 $',
    'path' => 'externals/desktop-notify',
    'repository' => 'socialengine.com',
    'title' => 'HTML5 Desktop Notifications',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/desktop-notify',
    )
  )
) ?>
