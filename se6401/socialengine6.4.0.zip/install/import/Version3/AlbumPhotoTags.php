<?php

class Install_Import_Version3_AlbumPhotoTags extends Install_Import_Version3_AbstractTags
{
  protected $_fromResourceType = 'media';

  protected $_toResourceType = 'album_photo';
}