<?php

class Install_Import_Ning_Cleanup extends Install_Import_Ning_Abstract
{
  protected $_priority = 10;
  
  public function run()
  {
    
  }

  protected function  _translateRow(array $data, $key = null) {
    ;
  }
}