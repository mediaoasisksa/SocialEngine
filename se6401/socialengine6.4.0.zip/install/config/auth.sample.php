<?php
/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    Install
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: auth.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

defined('SEIRAN_INSTALL') or die(); // Example (pw:test) test:seiran:8bd98fb521b3b05f121560c504526a3d ?>
someUser:someRealm:someMd5
